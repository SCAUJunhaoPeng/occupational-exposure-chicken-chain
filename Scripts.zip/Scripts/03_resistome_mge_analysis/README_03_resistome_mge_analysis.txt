03_resistome_mge_analysis
==========================

Purpose
-------
This folder contains the Python script used to summarize antimicrobial resistance,
metal-resistance and biocide-resistance profiles across the chicken supply-chain
metagenomic dataset.

The script generates:
- sample-level total abundance plots for AMR, METAL and BIOCIDE features;
- sample-level richness plots based on detected resistance classes;
- all-pair Mann-Whitney U tests with Benjamini-Hochberg correction;
- q-value heatmaps for pairwise comparisons;
- Bray-Curtis PCoA plots based on resistance-class profiles;
- PERMANOVA summaries for each subtype and grouping scheme.

Main script
-----------
03_resistome_analysis.py

Required input files
--------------------
Place the following files in the same directory as the script, or update the file
paths in the CONFIGURATION section of the script:

1. Group_302samples.xlsx
   Required metadata columns:
   - ID
   - Group

   Equivalent column names supported by the script include:
   - Sample, sample, SampleID, Sample_ID for sample IDs
   - group for group labels

2. AMR_METAL_BIOCIDE.csv
   Required columns:
   - Sample
   - Element subtype
   - Class
   - RPKM or Counts

   The abundance metric is controlled by the METRIC variable in the script:
   METRIC = "RPKM"

Expected element subtypes
-------------------------
The script analyzes the following feature types:
- AMR
- METAL
- BIOCIDE

Main outputs
------------
Outputs are written to:

Resistance_Exploratory_outputs_pairwise/

This directory includes:
- 01_base32/: analyses based on the predefined 32 sample groups and subsets;
- 02_explore/: exploratory analyses based on broader grouping schemes;
- raincloud plots in PNG and PDF formats;
- pairwise statistical tables in TSV format;
- q-value heatmaps in PNG and PDF formats;
- PCoA plots and PERMANOVA summaries.

Dependencies
------------
Python packages:
- numpy
- pandas
- matplotlib
- scipy
- openpyxl

Example command
---------------
python 03_resistome_analysis.py

Notes
-----
The script uses predefined group labels from the chicken supply-chain study.
If new group labels are added, update GROUP_ORDER, GROUP_CATEGORY and colour
mappings as needed.
