#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
plot_NF_bubble_top20_MetalsSecond_AIspace_hostOnly_v3.py

NF-style segmented bubble plot (AI-friendly spacing):
- Uses Host-derived genus ONLY (no 'g' column), so "Other" won't be artificially inflated.
- Segment order: AMR (top) -> Metals (middle) -> Bios (bottom)
- X-axis: Top N host genera (others NOT displayed). If a genus literally equals "Other" in Host, it will be appended as last column.
- Bubble size: count (sqrt-scaled by default) to reduce dominance of large bubbles.
- Colors: Okabe–Ito palette (print/colourblind friendly).
- Prevents cut-off bubbles at plot edges:
    * scatter(..., clip_on=False)
    * extra Y_PAD around y limits

Inputs in current working directory:
  AMR_gene.csv
  biocide_gene.csv
  metal_gene.csv

Output:
  NF_style_segmented_top20_MetalsSecond_AIspace_hostOnly_v3.pdf
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# ================== USER SETTINGS ==================
TOP_N = 20
SIZE_MODE = "sqrt"   # "sqrt" (recommended) / "linear" / "log"
OUT_PDF = "NF_style_segmented_top20_MetalsSecond_AIspace_hostOnly_v3.pdf"

# Segment order: Metals second
DATASETS = ("AMR", "Metals", "Bios")

# AI-friendly whitespace (no tight bbox)
FIGSIZE = (14.5, 9.6)
LEFT = 0.18
RIGHT = 0.78
TOP = 0.90
BOTTOM = 0.22

# Bubble clipping guard
Y_PAD = 1.0
# ===================================================

def extract_genus_from_host(host):
    s = str(host) if host is not None else ""
    s = s.replace("s__", "").strip()
    if not s or s.lower() == "nan":
        return "Unknown"
    return s.split()[0]

def prep(df, name):
    d = df.copy()
    d["Dataset"] = name
    d["Genus"] = d["Host"].apply(extract_genus_from_host)
    d["Class"] = d["Class"].fillna("Unknown").astype(str)
    return d[["Dataset", "Genus", "Class"]]

def size_transform(n, maxn, mode="sqrt", scale=900, base=10):
    n = np.asarray(n, float)
    maxn = float(maxn) if maxn else 1.0
    if mode == "linear":
        return (n / maxn) * scale + base
    if mode == "log":
        return (np.log1p(n) / np.log1p(maxn)) * scale + base
    return (np.sqrt(n) / np.sqrt(maxn)) * scale + base

def main():
    amr = pd.read_csv("AMR_gene.csv")
    bio = pd.read_csv("biocide_gene.csv")
    metal = pd.read_csv("metal_gene.csv")

    all_df = pd.concat(
        [prep(amr, "AMR"), prep(metal, "Metals"), prep(bio, "Bios")],
        ignore_index=True
    )

    # ---- top genera by total counts (Host-derived) ----
    genus_tot = (all_df[~all_df["Genus"].isin(["Unknown"])]
                 .groupby("Genus").size().sort_values(ascending=False))
    top_genera = genus_tot.head(TOP_N).index.tolist()

    # If "Other" literally exists as a genus label, append it last (NOT collapsing others!)
    include_host_other = ("Other" in genus_tot.index) and ("Other" not in top_genera)
    x_order = top_genera + (["Other"] if include_host_other else [])

    plot_df = all_df[all_df["Genus"].isin(x_order)].copy()

    # ---- y segments: dataset-specific class order ----
    classes_by_ds = {}
    for ds in DATASETS:
        sub = plot_df[plot_df["Dataset"] == ds]
        classes_by_ds[ds] = sub.groupby("Class").size().sort_values(ascending=False).index.tolist()

    y_pairs = []
    y_ranges = {}
    cur = 0
    for ds in DATASETS:
        start = cur
        for cls in classes_by_ds[ds]:
            y_pairs.append((ds, cls))
            cur += 1
        y_ranges[ds] = (start, cur - 1)

    # ---- counts ----
    ct = plot_df.groupby(["Dataset", "Class", "Genus"]).size().reset_index(name="n")
    x_map = {g: i for i, g in enumerate(x_order)}
    y_map = {pair: i for i, pair in enumerate(y_pairs)}

    xs, ys, ns, dss = [], [], [], []
    for _, r in ct.iterrows():
        pair = (r["Dataset"], r["Class"])
        if pair not in y_map:
            continue
        xs.append(x_map[r["Genus"]])
        ys.append(y_map[pair])
        ns.append(r["n"])
        dss.append(r["Dataset"])

    xs = np.array(xs, float)
    ys = np.array(ys, float)
    ns = np.array(ns, float)
    dss = np.array(dss, str)

    maxn = float(ns.max()) if len(ns) else 1.0
    sizes = size_transform(ns, maxn, mode=SIZE_MODE, scale=900, base=10)

    # Okabe–Ito palette
    palette = {"AMR": "#0072B2", "Bios": "#E69F00", "Metals": "#009E73"}
    offsets = {"AMR": -0.18, "Metals": 0.0, "Bios": 0.18}

    fig, ax = plt.subplots(figsize=FIGSIZE)

    # Background bands
    band = {"AMR": "#F2F6FF", "Metals": "#F0FBF6", "Bios": "#FFF7E8"}
    for ds in DATASETS:
        s, e = y_ranges[ds]
        if e >= s:
            ax.axhspan(s - 0.5, e + 0.5, color=band[ds], zorder=0)

    # Points (clip_on=False avoids cut-off bubbles)
    for ds in DATASETS:
        m = (dss == ds)
        ax.scatter(xs[m] + offsets[ds], ys[m],
                   s=sizes[m], alpha=0.82, linewidths=0,
                   color=palette[ds], label=ds, zorder=2, clip_on=False)

    # x axis
    ax.set_xticks(range(len(x_order)))
    ax.set_xticklabels(x_order, rotation=45, ha="right", fontsize=9)
    ax.set_xlabel(f"Host genus (Top {TOP_N} shown; others not displayed)", fontsize=10)

    # y axis
    y_labels = [cls for _ds, cls in y_pairs]
    ax.set_yticks(range(len(y_labels)))
    ax.set_yticklabels(y_labels, fontsize=8)
    ax.set_ylabel("Functional class", fontsize=10)

    # y padding
    ax.set_ylim(len(y_labels) - 0.5 + Y_PAD, -0.5 - Y_PAD)
    ax.set_xlim(-0.8, len(x_order) - 0.4)

    # Divider lines
    for i in range(len(DATASETS) - 1):
        ds = DATASETS[i]
        s, e = y_ranges[ds]
        if e >= s:
            ax.axhline(y=e + 0.5, color="#BDBDBD", linewidth=1.1, zorder=1)

    # Segment labels inside plot
    x_text = -0.55
    for ds in DATASETS:
        s, e = y_ranges[ds]
        if e >= s:
            ax.text(x_text, (s + e) / 2, ds, va="center", ha="right",
                    fontsize=11, fontweight="bold", color="#333333", zorder=3)

    # Minimal spines
    for spine in ("top", "right"):
        ax.spines[spine].set_visible(False)
    ax.tick_params(axis="both", length=0)

    # NF-style title + subtitle
    fig.text(LEFT, 0.955, "Host-associated resistance gene repertoires",
             ha="left", va="top", fontsize=13, fontweight="bold")
    fig.text(LEFT, 0.932,
             "Counts are aggregated by host genus and functional class; colours denote gene sets.",
             ha="left", va="top", fontsize=10, color="#333333")

    # Legends in right whitespace
    leg1 = ax.legend(title="Gene set", frameon=False,
                     loc="upper left", bbox_to_anchor=(1.01, 1.00),
                     fontsize=10, title_fontsize=10)
    ax.add_artist(leg1)

    ref = np.unique(np.maximum(1, np.round(np.array([0.33, 0.66, 1.0]) * maxn).astype(int)))
    handles, labels = [], []
    for r in ref:
        s = size_transform([r], maxn, mode=SIZE_MODE, scale=900, base=10)[0]
        handles.append(ax.scatter([], [], s=s, alpha=0.35, linewidths=0, color="#666666"))
        labels.append(str(int(r)))
    ax.legend(handles, labels, title="Count", frameon=False,
              loc="lower left", bbox_to_anchor=(1.01, 0.02),
              fontsize=10, title_fontsize=10)

    # keep whitespace for AI (no tight bbox)
    fig.subplots_adjust(left=LEFT, right=RIGHT, top=TOP, bottom=BOTTOM)
    fig.savefig(OUT_PDF)
    plt.close(fig)

    print("[OK] Saved:", OUT_PDF)

if __name__ == "__main__":
    main()
