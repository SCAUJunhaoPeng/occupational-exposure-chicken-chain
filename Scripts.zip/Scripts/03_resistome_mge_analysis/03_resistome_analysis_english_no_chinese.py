#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Resistome, metal-resistance and biocide-resistance exploratory analysis.

This script generates sample-level burden plots, pairwise statistical summaries,
q-value heatmaps, Bray-Curtis PCoA ordinations and PERMANOVA summaries for
AMR, METAL and BIOCIDE features across predefined sample groups and exploratory
metadata-derived groupings.

Expected inputs:
  - Group_302samples.xlsx: sample metadata with ID and Group columns.
  - AMR_METAL_BIOCIDE.csv: resistance-feature table with Sample, Element subtype,
    Class and abundance columns such as RPKM or Counts.

Main outputs are written to:
  - Resistance_Exploratory_outputs_pairwise/
"""

import os
import re
import hashlib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse
from scipy.stats import kruskal, mannwhitneyu

# =========================
# CONFIGURATION (edit here)
# =========================
GROUP_XLSX = r"Group_302samples.xlsx"
RESIST_CSV = r"AMR_METAL_BIOCIDE.csv"

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
OUTDIR = os.path.join(SCRIPT_DIR, "Resistance_Exploratory_outputs_pairwise")

METRIC = "RPKM"  # Use "RPKM" or "Counts"
SUBTYPES = ["AMR", "METAL", "BIOCIDE"]

# PCoA / PERMANOVA
N_PERM = 999
SHOW_ELLIPSE_MIN_N = 3
ELLIPSE_ALPHA = 0.18

# Raincloud
DETECT_THRESHOLD = 0.0
JITTER_SD = 0.06

# Significance annotation settings for many pairwise comparisons
ANNOTATE_ONLY_SIG = True         # Annotate only significant comparisons (q < 0.05)
ANNOTATE_Q_CUTOFF = 0.05
ANNOTATE_MAX_PAIRS = 40          # Maximum number of brackets to draw, ordered by q-value
ANNOTATE_NS = False              # Whether to show non-significant labels; generally not recommended

# Merge the three control human-faecal time points for the HumanFeces subset
COMBINE_CONTROL_HUMAN_FECES = True
CONTROL_GROUPS = ["C_Human_D1", "C_Human_D31", "C_Human_D57"]
CONTROL_COMBINED_NAME = "C_Human_Feces_Control"

# Output switches
RUN_BASE_32 = True
RUN_EXPLORATORY = True
EXPORT_HEATMAP = True            # Export q-value heatmaps for all pairwise comparisons

# Exploratory grouping plans; add or remove plans as needed
EXPLORATORY_PLANS = [
    {"name": "ALL_byStage", "subset": "ALL", "group_col": "Stage"},
    {"name": "ALL_byCategory", "subset": "ALL", "group_col": "Category"},
    {"name": "HumanFeces_bySource_NoTime", "subset": "HumanFeces", "group_col": "HumanSource_NoTime"},
    {"name": "HumanFeces_bySource_WithTime", "subset": "HumanFeces", "group_col": "HumanSource_WithTime"},
    {"name": "Chicken_byCompartment", "subset": "Chicken", "group_col": "ChickenCompartment"},
    {"name": "Environment_byCompartment", "subset": "Environment", "group_col": "EnvCompartment"},
]

# =========================
# Fixed 32-group order, colour palette and subset mapping
# =========================
GROUP_ORDER = [
    "C_Human_D1","C_Human_D31","C_Human_D57",
    "C_Human_H_D1","C_Human_H_D31","C_Human_H_D57",
    "F_D1","F_D31","F_D57",
    "F_F_D1","F_F_D31","F_F_D57",
    "F_W_D1","F_W_D31","F_W_D57",
    "F_W_H_D1","F_W_H_D31","F_W_H_D57",
    "S_E_C_D59","S_E_H_D59","S_E_W_D59",
    "S_P_YL_D59","S_P_C_D59",
    "S_C_C_D59","S_C_H_D59","S_C_W_D59","S_C_K_D59",
    "M_E_D60","M_SmWC_D60","M_SmCB_D60","M_SmCL_D60","M_W_D60"
]
GROUP_RANK = {g: i for i, g in enumerate(GROUP_ORDER)}

# Colour palette for the 32 predefined groups
CUSTOM_GROUP_COLORS = {
    # Control (purple)
    "C_Human_D1":    "#C69ECC",
    "C_Human_D31":   "#B27ABA",
    "C_Human_D57":   "#9D57A8",
    "C_Human_H_D1":  "#D9B0D9",
    "C_Human_H_D31": "#C089C4",
    "C_Human_H_D57": "#A55EAB",

    # Farm (green/teal)
    "F_D1":    "#9AD7B2",
    "F_D31":   "#63BF8D",
    "F_D57":   "#2FA76A",
    "F_F_D1":  "#B7D98A",
    "F_F_D31": "#8CC65A",
    "F_F_D57": "#5DB22A",
    "F_W_D1":  "#82CAB4",
    "F_W_D31": "#54B699",
    "F_W_D57": "#26A37E",
    "F_W_H_D1":  "#86C6D9",
    "F_W_H_D31": "#56AEC6",
    "F_W_H_D57": "#2C93B2",

    # Slaughter (blue)
    "S_E_C_D59":  "#2F6FAE",
    "S_E_H_D59":  "#5A95C7",
    "S_E_W_D59":  "#4184BC",
    "S_P_YL_D59": "#5AB8C7",
    "S_P_C_D59":  "#4FA2C7",
    "S_C_C_D59":  "#3E79C7",
    "S_C_H_D59":  "#6B7CCB",
    "S_C_W_D59":  "#4184BC",
    "S_C_K_D59":  "#7A8AA6",

    # Market (orange)
    "M_E_D60":     "#FFA64D",
    "M_SmWC_D60":  "#FF8F3D",
    "M_SmCB_D60":  "#FF7A2E",
    "M_SmCL_D60":  "#FFB24D",
    "M_W_D60":     "#FF850D",

    # Colour for the merged control reference group
    CONTROL_COMBINED_NAME: "#B27ABA",
}

# Category mapping used for subset analyses
GROUP_CATEGORY = {
    # Human faecal samples
    "C_Human_D1":"HumanFeces","C_Human_D31":"HumanFeces","C_Human_D57":"HumanFeces",
    "F_W_D1":"HumanFeces","F_W_D31":"HumanFeces","F_W_D57":"HumanFeces",
    "S_E_W_D59":"HumanFeces","S_C_W_D59":"HumanFeces","M_W_D60":"HumanFeces",

    # Chicken faecal, carcass and product samples
    "F_D1":"Chicken","F_D31":"Chicken","F_D57":"Chicken",
    "S_E_C_D59":"Chicken","S_P_C_D59":"Chicken","S_C_C_D59":"Chicken",
    "M_SmCB_D60":"Chicken","M_SmCL_D60":"Chicken","M_SmWC_D60":"Chicken",

    # Environmental samples
    "C_Human_H_D1":"Environment","C_Human_H_D31":"Environment","C_Human_H_D57":"Environment",
    "F_F_D1":"Environment","F_F_D31":"Environment","F_F_D57":"Environment",
    "F_W_H_D1":"Environment","F_W_H_D31":"Environment","F_W_H_D57":"Environment",
    "S_E_H_D59":"Environment","S_P_YL_D59":"Environment","S_C_H_D59":"Environment","S_C_K_D59":"Environment",
    "M_E_D60":"Environment",
}

RUN_PLAN_BASE = {
    "ALL": None,
    "HumanFeces": "HumanFeces",
    "Chicken": "Chicken",
    "Environment": "Environment",
}

# =========================
# Color system for exploratory groups
# =========================
STAGE_COLORS = {"C": "#B27ABA", "F": "#54B699", "S": "#4184BC", "M": "#FF850D", "Other": "#BDBDBD"}
CATEGORY_COLORS = {"HumanFeces": "#B27ABA", "Chicken": "#54B699", "Environment": "#4184BC", "Other": "#BDBDBD"}

# deterministic fallback palette by hashing label -> tab20 index
def stable_color_from_label(label: str):
    """Return a reproducible fallback colour for labels without a predefined colour."""
    cmap = plt.cm.tab20
    digest = hashlib.md5(str(label).encode("utf-8")).hexdigest()
    h = int(digest[:8], 16) % 20
    return cmap(h / 19.0)

def get_color(label: str, group_col: str = "Group"):
    """
    Return a color for any grouping label:
      - if it's a known 32-group label (or combined control): use CUSTOM_GROUP_COLORS
      - if grouping is Stage: use STAGE_COLORS
      - if grouping is Category: use CATEGORY_COLORS
      - else fallback deterministic tab20 hash
    """
    if label in CUSTOM_GROUP_COLORS:
        return CUSTOM_GROUP_COLORS[label]
    if group_col == "Stage":
        return STAGE_COLORS.get(label, "#BDBDBD")
    if group_col == "Category":
        return CATEGORY_COLORS.get(label, "#BDBDBD")
    return stable_color_from_label(str(label))

# =========================
# Utils
# =========================
def ensure_dir(d):
    os.makedirs(d, exist_ok=True)


def check_input_files():
    """Fail early if required input files are missing."""
    missing = [fp for fp in [GROUP_XLSX, RESIST_CSV] if not os.path.exists(fp)]
    if missing:
        raise FileNotFoundError(
            "Required input file(s) not found: "
            + ", ".join(missing)
            + ". Place the files in the working directory or update GROUP_XLSX and RESIST_CSV."
        )

def pick_col(df, candidates):
    for c in candidates:
        if c in df.columns:
            return c
    return None

def norm_id(x: str) -> str:
    x = str(x).strip()
    if re.fullmatch(r"\d+", x):
        return str(int(x))
    return x

def extract_sample_id_from_any(s: str) -> str:
    s = str(s).strip()
    m = re.match(r"(.+?)\.bin\.(\d+)$", s)
    if m: return m.group(1)
    m = re.match(r"bin\.(\d+)\.(.+)$", s)
    if m: return m.group(2)
    m = re.match(r"(.+?)_bin_(\d+)$", s)
    if m: return m.group(1)
    m = re.match(r"bin_(\d+)_(.+)$", s)
    if m: return m.group(2)
    s = re.sub(r"\.bin\.\d+$", "", s)
    return s.split(".")[0]

def bh_fdr(pvals):
    pvals = np.asarray(pvals, dtype=float)
    m = len(pvals)
    order = np.argsort(pvals)
    ranked = pvals[order]
    q = ranked * m / (np.arange(m) + 1)
    q = np.minimum.accumulate(q[::-1])[::-1]
    out = np.empty_like(q)
    out[order] = np.clip(q, 0, 1)
    return out

def p_to_star(p):
    if p < 1e-4: return "****"
    if p < 1e-3: return "***"
    if p < 1e-2: return "**"
    if p < 5e-2: return "*"
    return "ns"

def make_sample_sort_key(sample_id: str):
    if re.fullmatch(r"\d+", sample_id):
        return (0, int(sample_id), sample_id)
    return (1, sample_id, sample_id)

def apply_control_merge(df_sub: pd.DataFrame, subset_name: str) -> pd.DataFrame:
    if subset_name == "HumanFeces" and COMBINE_CONTROL_HUMAN_FECES:
        df_sub = df_sub.copy()
        df_sub.loc[df_sub["Group"].isin(CONTROL_GROUPS), "Group"] = CONTROL_COMBINED_NAME
    return df_sub

# =========================
# Derived metadata (exploratory)
# =========================
def parse_day(group_label: str):
    m = re.search(r"_D(\d+)$", str(group_label))
    return int(m.group(1)) if m else np.nan

def derive_meta_columns(sample_df: pd.DataFrame) -> pd.DataFrame:
    out = sample_df.copy()

    def stage_from_raw(g):
        g = str(g)
        if g.startswith("C_"): return "C"
        if g.startswith("F_"): return "F"
        if g.startswith("S_"): return "S"
        if g.startswith("M_"): return "M"
        return "Other"
    out["Stage"] = out["Group_raw"].map(stage_from_raw)
    out["Day"] = out["Group_raw"].map(parse_day)

    # human sources
    def human_source_no_time(gr, graw):
        # use raw to keep resolution even if group merged
        graw = str(graw)
        gr = str(gr)
        if gr == CONTROL_COMBINED_NAME or graw.startswith("C_Human_"):
            return "Control"
        if graw.startswith("F_W_"):
            return "FarmWorker"
        if graw.startswith("S_E_W_"):
            return "SlaughterWorker_Evis"
        if graw.startswith("S_C_W_"):
            return "SlaughterWorker_Cut"
        if graw.startswith("M_W_"):
            return "MarketWorker"
        return np.nan

    def human_source_with_time(row):
        graw = str(row["Group_raw"])
        gr = str(row["Group"])
        day = row["Day"]
        if gr == CONTROL_COMBINED_NAME or graw.startswith("C_Human_"):
            return f"Control_D{int(day)}" if np.isfinite(day) else "Control"
        if graw.startswith("F_W_"):
            return f"FarmWorker_D{int(day)}" if np.isfinite(day) else "FarmWorker"
        if graw.startswith("S_E_W_"):
            return "Slaughter_Evis_D59"
        if graw.startswith("S_C_W_"):
            return "Slaughter_Cut_D59"
        if graw.startswith("M_W_"):
            return "Market_D60"
        return np.nan

    def chicken_compartment(graw):
        graw = str(graw)
        if graw.startswith("F_D"):
            return f"FarmFeces_D{int(parse_day(graw))}"
        if graw.startswith("S_E_C_"):
            return "Slaughter_Gut_D59"
        if graw.startswith("S_P_C_"):
            return "Slaughter_Carcass_D59"
        if graw.startswith("S_C_C_"):
            return "Slaughter_Breast_D59"
        if graw.startswith("M_Sm"):
            return "Market_Product_D60"
        return np.nan

    def env_compartment(graw):
        graw = str(graw)
        if graw.startswith("C_Human_H_"):
            return f"Control_Hands_D{int(parse_day(graw))}"
        if graw.startswith("F_F_"):
            return f"Farm_Feed_D{int(parse_day(graw))}"
        if graw.startswith("F_W_H_"):
            return f"FarmWorker_Hands_D{int(parse_day(graw))}"
        if graw.startswith("S_E_H_"):
            return "Slaughter_Evis_Hands_D59"
        if graw.startswith("S_P_YL_"):
            return "Slaughter_ChillWater_D59"
        if graw.startswith("S_C_H_"):
            return "Slaughter_Cut_Hands_D59"
        if graw.startswith("S_C_K_"):
            return "Slaughter_KnifeBoard_D59"
        if graw.startswith("M_E_"):
            return "Market_Env_D60"
        return np.nan

    out["HumanSource_NoTime"] = [human_source_no_time(g, r) for g, r in zip(out["Group"], out["Group_raw"])]
    out["HumanSource_WithTime"] = out.apply(human_source_with_time, axis=1)
    out["ChickenCompartment"] = out["Group_raw"].map(chicken_compartment)
    out["EnvCompartment"] = out["Group_raw"].map(env_compartment)

    return out

# =========================
# Distance / Ordination / PERMANOVA
# =========================
def bray_curtis(X):
    X = np.asarray(X, dtype=float)
    n = X.shape[0]
    D = np.zeros((n, n), dtype=float)
    sums = X.sum(axis=1)
    for i in range(n):
        xi = X[i]
        for j in range(i+1, n):
            xj = X[j]
            denom = sums[i] + sums[j]
            d = 0.0 if denom == 0 else 1.0 - (2.0 * np.minimum(xi, xj).sum() / denom)
            D[i, j] = D[j, i] = d
    return D

def pcoa(D):
    D = np.asarray(D, dtype=float)
    n = D.shape[0]
    D2 = D ** 2
    J = np.eye(n) - np.ones((n, n)) / n
    B = -0.5 * J @ D2 @ J
    eigvals, eigvecs = np.linalg.eigh(B)
    idx = np.argsort(eigvals)[::-1]
    eigvals = eigvals[idx]
    eigvecs = eigvecs[:, idx]
    pos = eigvals > 1e-12
    eigvals_pos = eigvals[pos]
    eigvecs_pos = eigvecs[:, pos]
    if eigvals_pos.size < 2:
        return np.zeros((n, 2)), np.array([0.0, 0.0])
    coords = eigvecs_pos[:, :2] * np.sqrt(eigvals_pos[:2])
    var = eigvals_pos[:2] / eigvals_pos.sum() * 100.0
    return coords, var

def permanova(D, groups, n_perm=999, seed=0):
    rng = np.random.default_rng(seed)
    groups = np.asarray(groups)
    n = len(groups)
    A = -0.5 * (D ** 2)
    grand_mean = A.mean()
    SST = ((A - grand_mean) ** 2).sum()

    uniq = np.unique(groups)
    X = np.zeros((n, len(uniq)))
    for k, g in enumerate(uniq):
        X[:, k] = (groups == g).astype(float)

    XtX_inv = np.linalg.pinv(X.T @ X)
    H = X @ XtX_inv @ X.T

    SS_between = np.trace(H @ A) - np.trace(H) * grand_mean
    SS_within = SST - SS_between
    df_between = len(uniq) - 1
    df_within = n - len(uniq)
    MS_between = SS_between / max(df_between, 1)
    MS_within = SS_within / max(df_within, 1)
    F_obs = MS_between / MS_within if MS_within > 0 else np.inf
    R2 = SS_between / SST if SST > 0 else 0.0

    count = 0
    for _ in range(n_perm):
        perm = rng.permutation(groups)
        Xp = np.zeros_like(X)
        for k, g in enumerate(uniq):
            Xp[:, k] = (perm == g).astype(float)
        Hp = Xp @ XtX_inv @ Xp.T
        SSb_p = np.trace(Hp @ A) - np.trace(Hp) * grand_mean
        MSp = SSb_p / max(df_between, 1)
        Fp = MSp / MS_within if MS_within > 0 else np.inf
        if Fp >= F_obs:
            count += 1
    p = (count + 1) / (n_perm + 1)
    return F_obs, R2, p

def add_ellipse(ax, x, y, color, alpha=0.2):
    pts = np.vstack([x, y]).T
    cov = np.cov(pts, rowvar=False)
    if cov.shape != (2, 2) or np.any(~np.isfinite(cov)):
        return
    vals, vecs = np.linalg.eigh(cov)
    order = vals.argsort()[::-1]
    vals, vecs = vals[order], vecs[:, order]
    chi2_95 = 5.991
    width, height = 2 * np.sqrt(vals * chi2_95)
    angle = np.degrees(np.arctan2(vecs[1, 0], vecs[0, 0]))
    ell = Ellipse((np.mean(x), np.mean(y)), width, height, angle=angle,
                  facecolor=color, edgecolor=color, alpha=alpha, linewidth=1.0)
    ax.add_patch(ell)

def plot_pcoa(coords, var, groups, title, out_png, out_pdf, group_col, order):
    fig = plt.figure(figsize=(6.8, 5.6), dpi=300)
    ax = fig.add_subplot(1, 1, 1)

    groups = np.asarray(groups)
    order = [g for g in order if g in set(groups)]
    if len(order) == 0:
        order = sorted(set(groups))

    for g in order:
        idx = np.where(groups == g)[0]
        if idx.size == 0:
            continue
        x = coords[idx, 0]
        y = coords[idx, 1]
        ax.scatter(x, y, s=18, color=get_color(g, group_col), label=g, edgecolor="none")
        if idx.size >= SHOW_ELLIPSE_MIN_N:
            add_ellipse(ax, x, y, get_color(g, group_col), alpha=ELLIPSE_ALPHA)

    ax.axhline(0, linewidth=0.6, alpha=0.5)
    ax.axvline(0, linewidth=0.6, alpha=0.5)
    ax.set_xlabel(f"PCoA1 ({var[0]:.1f}%)")
    ax.set_ylabel(f"PCoA2 ({var[1]:.1f}%)")
    ax.set_title(title)
    ax.legend(frameon=False, fontsize=7, bbox_to_anchor=(1.02, 1.0), loc="upper left")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    fig.tight_layout()
    fig.savefig(out_png, bbox_inches="tight")
    fig.savefig(out_pdf, bbox_inches="tight")
    plt.close(fig)

# =========================
# Pairwise tests (ALL pairs)
# =========================
def pairwise_mwu_all(values_df, value_col, group_col, order):
    """
    All pairwise MWU (two-sided) + BH-FDR.
    Returns df with Group1, Group2, p, q_BH
    """
    order = [g for g in order if g in set(values_df[group_col].dropna().unique())]
    pairs = []
    pvals = []
    for i in range(len(order)):
        for j in range(i + 1, len(order)):
            g1, g2 = order[i], order[j]
            a = values_df.loc[values_df[group_col] == g1, value_col].values
            b = values_df.loc[values_df[group_col] == g2, value_col].values
            if len(a) == 0 or len(b) == 0:
                continue
            _, p = mannwhitneyu(a, b, alternative="two-sided")
            pairs.append((g1, g2))
            pvals.append(p)

    if len(pvals) == 0:
        return pd.DataFrame(columns=["Group1", "Group2", "p", "q_BH"])

    q = bh_fdr(pvals)
    out = pd.DataFrame({
        "Group1": [p[0] for p in pairs],
        "Group2": [p[1] for p in pairs],
        "p": pvals,
        "q_BH": q
    }).sort_values(["q_BH", "p"])
    return out

def annotate_pairwise_brackets(ax, order, pw_df, y_max, q_cutoff=0.05, max_pairs=40):
    """
    Annotate significant pairwise comparisons on the plot using brackets.
    To keep it readable, annotate only:
      - q<q_cutoff (if ANNOTATE_ONLY_SIG)
      - up to max_pairs with smallest q
    """
    if pw_df.empty:
        return

    df = pw_df.copy()
    if ANNOTATE_ONLY_SIG:
        df = df[df["q_BH"] < q_cutoff].copy()
    if df.empty:
        return

    df = df.sort_values("q_BH").head(max_pairs)

    # y positions
    if not np.isfinite(y_max) or y_max <= 0:
        y_max = 1.0
    y_base = y_max * 1.06
    y_step = y_max * 0.08
    h = y_step * 0.25

    # bracket stacking: by span length
    df["i1"] = df["Group1"].map(lambda g: order.index(g))
    df["i2"] = df["Group2"].map(lambda g: order.index(g))
    df["span"] = (df[["i1", "i2"]].max(axis=1) - df[["i1", "i2"]].min(axis=1))
    df = df.sort_values(["q_BH", "span"], ascending=[True, False])

    for k, row in enumerate(df.itertuples(index=False)):
        left = min(row.i1, row.i2)
        right = max(row.i1, row.i2)
        y = y_base + k * y_step
        ax.plot([left, left, right, right], [y, y + h, y + h, y], linewidth=0.8)
        star = p_to_star(float(row.q_BH))
        if (star == "ns") and (not ANNOTATE_NS):
            continue
        ax.text((left + right) / 2, y + h * 1.15, star, ha="center", va="bottom", fontsize=10)

    ax.set_ylim(top=y_base + (len(df) + 1) * y_step + y_step * 0.8)

def plot_pairwise_heatmap(pw_df, order, title, out_png, out_pdf):
    """
    Heatmap of q_BH for all pairs.
    """
    n = len(order)
    mat = np.ones((n, n), dtype=float)
    np.fill_diagonal(mat, np.nan)

    idx_map = {g: i for i, g in enumerate(order)}
    for r in pw_df.itertuples(index=False):
        i = idx_map.get(r.Group1, None)
        j = idx_map.get(r.Group2, None)
        if i is None or j is None:
            continue
        mat[i, j] = mat[j, i] = float(r.q_BH)

    fig_w = max(8, n * 0.35)
    fig = plt.figure(figsize=(fig_w, fig_w), dpi=300)
    ax = fig.add_subplot(1, 1, 1)

    im = ax.imshow(mat, interpolation="nearest")
    ax.set_xticks(np.arange(n))
    ax.set_yticks(np.arange(n))
    ax.set_xticklabels(order, rotation=90, fontsize=7)
    ax.set_yticklabels(order, fontsize=7)
    ax.set_title(title)
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04, label="q_BH")

    fig.tight_layout()
    fig.savefig(out_png, bbox_inches="tight")
    fig.savefig(out_pdf, bbox_inches="tight")
    plt.close(fig)

# =========================
# Raincloud plot with ALL-pairs significance
# =========================
def plot_raincloud_allpairs(values_df, value_col, title, out_png, out_pdf, group_col, order):
    """
    Raincloud (violin + box + jitter) with:
      - overall Kruskal–Wallis
      - all-pairs MWU + BH (export table)
      - annotate significant pairs (limited) on plot
    """
    order = [g for g in order if g in set(values_df[group_col].dropna().unique())]
    if len(order) == 0:
        return pd.DataFrame(columns=["Group1", "Group2", "p", "q_BH"])

    # overall Kruskal
    arrays = [values_df.loc[values_df[group_col] == g, value_col].values for g in order]
    arrays_nonempty = [a for a in arrays if len(a) > 0]
    if len(arrays_nonempty) >= 2:
        _, p_kw = kruskal(*arrays_nonempty)
        kw_text = f"Kruskal–Wallis p={p_kw:.3g}"
    else:
        kw_text = "Kruskal–Wallis p=NA"

    # all pairs
    pw = pairwise_mwu_all(values_df, value_col, group_col, order)

    # plot
    fig_w = max(10, len(order) * 0.42)
    fig = plt.figure(figsize=(fig_w, 5.8), dpi=300)
    ax = fig.add_subplot(1, 1, 1)

    x = np.arange(len(order))
    data = [values_df.loc[values_df[group_col] == g, value_col].values for g in order]

    parts = ax.violinplot(data, positions=x, widths=0.85, showmeans=False, showextrema=False, showmedians=False)
    for i, body in enumerate(parts["bodies"]):
        g = order[i]
        body.set_facecolor(get_color(g, group_col))
        body.set_edgecolor("none")
        body.set_alpha(0.22)

    bp = ax.boxplot(data, positions=x, widths=0.18, patch_artist=True, showfliers=False)
    for i, box in enumerate(bp["boxes"]):
        g = order[i]
        box.set_facecolor(get_color(g, group_col))
        box.set_alpha(0.55)
        box.set_edgecolor("black")
        box.set_linewidth(0.6)
    for key in ["medians", "whiskers", "caps"]:
        for line in bp[key]:
            line.set_color("black")
            line.set_linewidth(0.6)

    rng = np.random.default_rng(0)
    for i, g in enumerate(order):
        vals = data[i]
        if len(vals) == 0:
            continue
        jitter = rng.normal(0, JITTER_SD, size=len(vals))
        ax.scatter(np.full(len(vals), i) + jitter, vals, s=12,
                   color=get_color(g, group_col), alpha=0.85, edgecolor="none")

    ax.set_xticks(x)
    ax.set_xticklabels(order, rotation=90, fontsize=8)
    ax.set_ylabel(value_col)
    ax.set_title(f"{title} | {kw_text}")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    y_max = float(np.nanmax(values_df[value_col].values)) if len(values_df) else 1.0
    annotate_pairwise_brackets(
        ax=ax,
        order=order,
        pw_df=pw,
        y_max=y_max,
        q_cutoff=ANNOTATE_Q_CUTOFF,
        max_pairs=ANNOTATE_MAX_PAIRS
    )

    fig.tight_layout()
    fig.savefig(out_png, bbox_inches="tight")
    fig.savefig(out_pdf, bbox_inches="tight")
    plt.close(fig)

    return pw

# =========================
# Load data
# =========================
def load_group_map():
    grp = pd.read_excel(GROUP_XLSX)
    id_col = pick_col(grp, ["ID", "Sample", "sample", "SampleID", "Sample_ID"])
    g_col = pick_col(grp, ["Group", "group"])
    if id_col is None or g_col is None:
        raise ValueError("The group metadata file must contain ID and Group columns, or equivalent column names.")
    grp = grp.rename(columns={id_col: "ID", g_col: "Group"})
    grp["ID"] = grp["ID"].astype(str).str.strip()
    grp["Group"] = grp["Group"].astype(str).str.strip()
    return {norm_id(i): g for i, g in zip(grp["ID"], grp["Group"])}

def load_resistance(id_to_group):
    df = pd.read_csv(RESIST_CSV)
    sample_col = pick_col(df, ["Sample", "sample", "SAMPLE"])
    subtype_col = pick_col(df, ["Element subtype", "Element_subtype", "Subtype", "subtype"])
    class_col = pick_col(df, ["Class", "class"])
    metric_col = pick_col(df, [METRIC, METRIC.lower()])
    if sample_col is None or subtype_col is None or class_col is None:
        raise ValueError("The resistance table must contain the following columns: Sample, Element subtype and Class.")
    if metric_col is None:
        raise ValueError(f"The resistance table does not contain the requested abundance column: {METRIC}")

    df["Sample_ID"] = df[sample_col].map(extract_sample_id_from_any).map(norm_id)
    df["Group_raw"] = df["Sample_ID"].map(lambda x: id_to_group.get(x, np.nan))
    df = df.dropna(subset=["Group_raw"]).copy()
    df = df[df[subtype_col].isin(SUBTYPES)].copy()

    df["Category"] = df["Group_raw"].map(lambda g: GROUP_CATEGORY.get(g, "Other"))
    df[metric_col] = pd.to_numeric(df[metric_col], errors="coerce").fillna(0.0)
    df[class_col] = df[class_col].astype(str).replace("nan", "Unclassified")

    df["Group"] = df["Group_raw"].astype(str)
    return df, subtype_col, class_col, metric_col

def get_subset_df(df_all, subset_name):
    if subset_name == "ALL":
        return df_all.copy()
    return df_all[df_all["Category"] == subset_name].copy()

# =========================
# Build sample-level metrics
# =========================
def compute_sample_metrics(df_sub, subtype_col, class_col, metric_col):
    sample_base = df_sub[["Sample_ID", "Group", "Group_raw", "Category"]].drop_duplicates().copy()
    for st in SUBTYPES:
        d = df_sub[df_sub[subtype_col] == st].copy()
        tot = d.groupby("Sample_ID")[metric_col].sum()
        det = (d.groupby(["Sample_ID", class_col])[metric_col].sum().reset_index()
                 .assign(detected=lambda x: x[metric_col] > DETECT_THRESHOLD)
                 .groupby("Sample_ID")["detected"].sum())
        sample_base[f"{st}_total"] = sample_base["Sample_ID"].map(tot).fillna(0.0)
        sample_base[f"{st}_nClass"] = sample_base["Sample_ID"].map(det).fillna(0).astype(int)
    return sample_base

def build_class_profile_matrix(df_st, class_col, metric_col, sample_meta, group_col):
    sm = sample_meta[["Sample_ID", group_col]].drop_duplicates().copy()
    sm = sm.dropna(subset=[group_col])
    if sm.empty:
        return None
    ordered_samples = sm["Sample_ID"].tolist()
    groups = sm[group_col].tolist()

    mat = (df_st.groupby(["Sample_ID", class_col])[metric_col].sum().reset_index()
             .pivot_table(index="Sample_ID", columns=class_col, values=metric_col, fill_value=0.0))
    mat = mat.reindex(index=ordered_samples).fillna(0.0)
    return mat.values, ordered_samples, groups

# =========================
# Order builders for different grouping columns
# =========================
def make_order_for_group_col(sample_metrics: pd.DataFrame, group_col: str, subset_name: str):
    labels = sample_metrics[group_col].dropna().unique().tolist()
    labels_set = set(labels)

    if group_col == "Group":
        if subset_name == "HumanFeces" and COMBINE_CONTROL_HUMAN_FECES:
            base = [g for g in GROUP_ORDER if g not in CONTROL_GROUPS]
            insert_pos = 0
            idxs = [GROUP_ORDER.index(g) for g in CONTROL_GROUPS if g in GROUP_ORDER]
            if len(idxs):
                insert_pos = min(idxs)
            base.insert(insert_pos, CONTROL_COMBINED_NAME)
            order = [g for g in base if g in labels_set]
            leftovers = [g for g in sorted(labels_set) if g not in set(order)]
            return order + leftovers
        order = [g for g in GROUP_ORDER if g in labels_set]
        leftovers = [g for g in sorted(labels_set) if g not in set(order)]
        return order + leftovers

    if group_col == "Stage":
        order = ["C", "F", "S", "M", "Other"]
        return [g for g in order if g in labels_set] + [g for g in sorted(labels_set) if g not in set(order)]

    if group_col == "Category":
        order = ["HumanFeces", "Chicken", "Environment", "Other"]
        return [g for g in order if g in labels_set] + [g for g in sorted(labels_set) if g not in set(order)]

    # for other meta labels, keep stable: sort by label
    return sorted(labels_set)

# =========================
# Run a block (plots + stats) for any grouping column
# =========================
def run_block(outdir_block, df_block, subset_name, subtype_col, class_col, metric_col, group_col_for_tests):
    ensure_dir(outdir_block)

    sample_metrics = compute_sample_metrics(df_block, subtype_col, class_col, metric_col)
    sample_metrics = derive_meta_columns(sample_metrics)

    # order of groups for this group_col
    order_labels = make_order_for_group_col(sample_metrics, group_col_for_tests, subset_name)

    # ---- raincloud + pairwise tables + heatmap ----
    for st in SUBTYPES:
        # total
        pw1 = plot_raincloud_allpairs(
            values_df=sample_metrics,
            value_col=f"{st}_total",
            title=f"{subset_name} | {group_col_for_tests} | {st} total ({METRIC})",
            out_png=os.path.join(outdir_block, f"{subset_name}_{group_col_for_tests}_{st}_total_raincloud.png"),
            out_pdf=os.path.join(outdir_block, f"{subset_name}_{group_col_for_tests}_{st}_total_raincloud.pdf"),
            group_col=group_col_for_tests,
            order=order_labels
        )
        pw1.to_csv(os.path.join(outdir_block, f"{subset_name}_{group_col_for_tests}_{st}_total_pairwise_allpairs_BH.tsv"),
                   sep="\t", index=False)
        if EXPORT_HEATMAP and (not pw1.empty):
            plot_pairwise_heatmap(
                pw_df=pw1,
                order=order_labels,
                title=f"{subset_name} | {group_col_for_tests} | {st}_total q_BH heatmap",
                out_png=os.path.join(outdir_block, f"{subset_name}_{group_col_for_tests}_{st}_total_pairwise_heatmap.png"),
                out_pdf=os.path.join(outdir_block, f"{subset_name}_{group_col_for_tests}_{st}_total_pairwise_heatmap.pdf"),
            )

        # nClass
        pw2 = plot_raincloud_allpairs(
            values_df=sample_metrics,
            value_col=f"{st}_nClass",
            title=f"{subset_name} | {group_col_for_tests} | {st} nClass",
            out_png=os.path.join(outdir_block, f"{subset_name}_{group_col_for_tests}_{st}_nClass_raincloud.png"),
            out_pdf=os.path.join(outdir_block, f"{subset_name}_{group_col_for_tests}_{st}_nClass_raincloud.pdf"),
            group_col=group_col_for_tests,
            order=order_labels
        )
        pw2.to_csv(os.path.join(outdir_block, f"{subset_name}_{group_col_for_tests}_{st}_nClass_pairwise_allpairs_BH.tsv"),
                   sep="\t", index=False)
        if EXPORT_HEATMAP and (not pw2.empty):
            plot_pairwise_heatmap(
                pw_df=pw2,
                order=order_labels,
                title=f"{subset_name} | {group_col_for_tests} | {st}_nClass q_BH heatmap",
                out_png=os.path.join(outdir_block, f"{subset_name}_{group_col_for_tests}_{st}_nClass_pairwise_heatmap.png"),
                out_pdf=os.path.join(outdir_block, f"{subset_name}_{group_col_for_tests}_{st}_nClass_pairwise_heatmap.pdf"),
            )

    # ---- PCoA + PERMANOVA ----
    pcoa_dir = os.path.join(outdir_block, "PCoA")
    ensure_dir(pcoa_dir)
    perm_rows = []

    sm = sample_metrics[["Sample_ID", group_col_for_tests]].dropna().copy()
    if sm.empty:
        return

    # stable sort for sample order
    rank_map = {g: i for i, g in enumerate(order_labels)}
    sm["g_rank"] = sm[group_col_for_tests].map(lambda x: rank_map.get(x, 10**9))
    sm["s_rank"] = sm["Sample_ID"].map(make_sample_sort_key)
    sm = sm.sort_values(["g_rank", group_col_for_tests, "s_rank", "Sample_ID"], kind="mergesort")
    sm.to_csv(os.path.join(outdir_block, f"{subset_name}_{group_col_for_tests}_ordered_samples.tsv"),
              sep="\t", index=False)

    for st in SUBTYPES:
        df_st = df_block[df_block[subtype_col] == st].copy()
        if df_st.empty:
            continue
        X_pack = build_class_profile_matrix(df_st, class_col, metric_col, sm, group_col_for_tests)
        if X_pack is None:
            continue
        X, samples, groups = X_pack
        if len(samples) < 3 or len(set(groups)) < 2:
            continue

        D = bray_curtis(X)
        coords, var = pcoa(D)
        F, R2, p = permanova(D, np.array(groups), n_perm=N_PERM, seed=0)
        perm_rows.append({
            "subset": subset_name,
            "grouping": group_col_for_tests,
            "subtype": st,
            "n_samples": len(samples),
            "n_groups": len(set(groups)),
            "F": F, "R2": R2, "p": p
        })

        title = f"{subset_name} | {group_col_for_tests} | {st} PCoA (Bray–Curtis) | PERMANOVA R2={R2:.3f}, p={p:.3g}"
        plot_pcoa(
            coords=coords,
            var=var,
            groups=np.array(groups),
            title=title,
            out_png=os.path.join(pcoa_dir, f"{subset_name}_{group_col_for_tests}_{st}_PCoA.png"),
            out_pdf=os.path.join(pcoa_dir, f"{subset_name}_{group_col_for_tests}_{st}_PCoA.pdf"),
            group_col=group_col_for_tests,
            order=order_labels
        )

    pd.DataFrame(perm_rows).to_csv(os.path.join(outdir_block, "PERMANOVA_summary.tsv"), sep="\t", index=False)

# =========================
# MAIN
# =========================
def main():
    check_input_files()
    ensure_dir(OUTDIR)
    base_dir = os.path.join(OUTDIR, "01_base32")
    explore_dir = os.path.join(OUTDIR, "02_explore")
    ensure_dir(base_dir)
    ensure_dir(explore_dir)

    id_to_group = load_group_map()
    df_all, subtype_col, class_col, metric_col = load_resistance(id_to_group)

    # ========== 01) Base analyses (32-group + subsets) ==========
    if RUN_BASE_32:
        for subset_name in RUN_PLAN_BASE.keys():
            df_sub = get_subset_df(df_all, subset_name)
            if subset_name == "HumanFeces":
                df_sub = apply_control_merge(df_sub, "HumanFeces")
            out_block = os.path.join(base_dir, subset_name)
            run_block(
                outdir_block=out_block,
                df_block=df_sub,
                subset_name=subset_name,
                subtype_col=subtype_col,
                class_col=class_col,
                metric_col=metric_col,
                group_col_for_tests="Group"
            )

    # ========== 02) Exploratory analyses ==========
    if RUN_EXPLORATORY:
        for plan in EXPLORATORY_PLANS:
            name = plan["name"]
            subset = plan["subset"]
            group_col = plan["group_col"]

            df_sub = get_subset_df(df_all, subset)
            if subset == "HumanFeces":
                df_sub = apply_control_merge(df_sub, "HumanFeces")

            out_block = os.path.join(explore_dir, name)
            run_block(
                outdir_block=out_block,
                df_block=df_sub,
                subset_name=subset,
                subtype_col=subtype_col,
                class_col=class_col,
                metric_col=metric_col,
                group_col_for_tests=group_col
            )

    print(f"[DONE] All outputs saved to: {OUTDIR}")

if __name__ == "__main__":
    main()