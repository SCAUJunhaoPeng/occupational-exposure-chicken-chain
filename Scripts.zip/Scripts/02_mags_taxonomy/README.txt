02_mags_taxonomy
================

Purpose
-------
This folder contains the R script used to generate multi-rank MAG taxonomic
composition plots for the occupational-exposure chicken-chain study.

Script
------
02_mags_taxonomy.R

Required input files
--------------------
Place the following files in the project root directory, or update the file
paths in the USER SETTINGS section of the R script.

1. mags_95_75_10.tsv
   MAG abundance table. The first column should contain MAG IDs, and all
   remaining columns should correspond to sample IDs.

2. GTDB_taxonomy.tsv
   MAG taxonomy table. The script recognizes MAG_bin, user_genome, MAG_ID,
   MAG, Bin, bin, Genome or genome as the MAG identifier column. It uses
   Family, Genus and Species columns when available; otherwise, it parses
   f__, g__ and s__ fields from a gtdb_taxonomy column.

3. Group_302_all.xlsx
   Sample metadata table. The default required columns are ID and Group.
   Optional columns include Sample type and Stages.

Outputs
-------
The script creates the following output directory:

MAG_multi_rank_barplots/

For each taxonomic rank, the script exports three panel-specific stacked
bar plots:

- A_human
- B_chicken
- C_environment

Each plot is exported as both PDF and PNG. The script also exports color
mapping tables and a sample-to-panel check table.

How to run
----------
From the project root directory:

Rscript scripts/02_mags_taxonomy/02_mags_taxonomy.R

Dependencies
------------
R packages:

- tidyverse
- readxl
- openxlsx
- scales
- stringr
- forcats

Notes
-----
The script uses relative paths and is designed for reproducible use from
the project root directory. It avoids local absolute paths and generates
all outputs under MAG_multi_rank_barplots/.


Compatibility note:
  The panel-assignment rules use English metadata keywords only.
  Please standardize metadata values such as worker, human, chicken, carcass, feces, meat, environment, hand, knife, water and board before running the script.
