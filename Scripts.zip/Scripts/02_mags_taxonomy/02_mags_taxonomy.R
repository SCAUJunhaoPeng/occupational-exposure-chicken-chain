# =========================================================
# 02_mags_taxonomy.R
# =========================================================
# Purpose:
#   Generate publication-ready stacked bar plots of MAG taxonomic
#   composition at family, genus and species levels.
#
# Required input files:
#   1. mags_95_75_10.tsv      MAG abundance table; first column = MAG ID,
#                             remaining columns = sample IDs.
#   2. GTDB_taxonomy.tsv      MAG taxonomy table; must contain MAG_bin or
#                             another recognizable MAG/genome ID column.
#   3. Group_302_all.xlsx     Sample metadata table; must contain ID and Group.
#
# Main outputs:
#   MAG_multi_rank_barplots/
#     Family/
#     Genus/
#     Species/
#     Sample_group_stage_panel_map.xlsx
#
# Notes:
#   The script uses relative paths and is intended to be run from the
#   project root directory.
# =========================================================

suppressPackageStartupMessages({
  library(tidyverse)
  library(readxl)
  library(openxlsx)
  library(scales)
  library(stringr)
  library(forcats)
})

# =========================================================
# 0. CANVAS / FIGURE CONTROL
# =========================================================
MAG_ABUND_FP <- "mags_95_75_10.tsv"
TAX_FP       <- "GTDB_taxonomy.tsv"
GROUP_FP     <- "Group_302_all.xlsx"
OUT_DIR      <- "MAG_multi_rank_barplots"

check_required_file <- function(path, label) {
  if (!file.exists(path)) {
    stop(
      paste0(label, " was not found: ", path,
             "\nPlease check the input file name or update the path in the USER SETTINGS section."),
      call. = FALSE
    )
  }
}

check_required_file(MAG_ABUND_FP, "MAG abundance table")
check_required_file(TAX_FP, "MAG taxonomy table")
check_required_file(GROUP_FP, "Sample metadata table")

dir.create(OUT_DIR, showWarnings = FALSE, recursive = TRUE)

# Taxonomic ranks to be exported
TAX_RANKS <- c("Family", "Genus", "Species")

TOP_N_TAXA <- list(
  Family  = 18,
  Genus   = 18,
  Species = 18
)

# ---- Figure layout parameters ----
BASE_PDF_WIDTH   <- 11
BASE_PDF_HEIGHT  <- 6.0
WIDTH_PER_SAMPLE <- 0.11
EXTRA_WIDTH      <- 2.2

BOTTOM_BAR_YMIN  <- -5.6
BOTTOM_BAR_YMAX  <- -1.1
TOP_BAR_YMIN     <- 101.2
TOP_BAR_YMAX     <- 107.0
Y_MIN            <- -6.0
Y_MAX            <- 107.8

GROUP_TEXT_SIZE   <- 2.4
STAGE_TEXT_SIZE   <- 3.8
AXIS_TEXT_Y_SIZE  <- 9
AXIS_TITLE_SIZE   <- 11

LEGEND_NROW       <- 3
LEGEND_BYROW      <- TRUE
LEGEND_KEY_SIZE   <- 0.32
LEGEND_BOX_MARGIN <- 2
LEGEND_MARGIN_T   <- 2
LEGEND_TEXT_SIZE  <- 7.4
LEGEND_TITLE_SIZE <- 9.5
PLOT_MARGIN_B     <- 26

# Fixed column names
FORCE_SAMPLE_COL <- "ID"
FORCE_GROUP_COL  <- "Group"
FORCE_TYPE_COL   <- "Sample type"
FORCE_STAGE_COL  <- "Stages"

FORCE_TAX_MAG_COL  <- "MAG_bin"
FORCE_TAXONOMY_COL <- "gtdb_taxonomy"

# If fixed columns are absent, fall back to automatic column detection
META_SAMPLE_CANDIDATES <- c("ID", "SampleID", "Sample", "sample", "sample_id")
META_GROUP_CANDIDATES  <- c("Group", "group", "GroupName", "group_name")
META_TYPE_CANDIDATES   <- c("Sample type", "SampleType", "sample_type", "Type", "type", "Category", "category")
META_STAGE_CANDIDATES  <- c("Stages", "Stage", "stage", "stages")

# =========================================================
# 1. Color palettes
# =========================================================
base_taxa_colors <- c(
  "#F4B183", "#C97A34", "#9FD3C7", "#F1E06E", "#9E9AC8", "#CFCFDE",
  "#A5D17A", "#DCC277", "#2F67B1", "#58A65C", "#6A51A3", "#F2D7C9",
  "#B7791F", "#A7C7E7", "#F2B447", "#F46D43", "#9E0142", "#7A0177",
  "#CC78A8", "#66C2A5", "#E6B8D4", "#7F7F7F", "#8DD3C7", "#FFFFB3",
  "#BEBADA", "#FB8072", "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
  "#BC80BD", "#CCEBC5", "#FFED6F", "#1F78B4", "#33A02C", "#E31A1C"
)

make_taxa_palette <- function(taxa_levels) {
  taxa_levels <- unique(taxa_levels)
  n <- length(taxa_levels)
  
  pal <- base_taxa_colors
  if (n > length(pal)) {
    extra_n <- n - length(pal)
    extra_pal <- colorRampPalette(c(
      "#8DD3C7", "#FFFFB3", "#BEBADA", "#FB8072",
      "#80B1D3", "#FDB462", "#B3DE69", "#FCCDE5",
      "#BC80BD", "#CCEBC5", "#FFED6F"
    ))(extra_n)
    pal <- c(pal, extra_pal)
  }
  
  pal <- pal[seq_len(n)]
  names(pal) <- taxa_levels
  
  if ("Other" %in% taxa_levels) {
    pal["Other"] <- "#C6DDBF"
  }
  if ("Unclassified" %in% taxa_levels) {
    pal["Unclassified"] <- "#D9D9D9"
  }
  pal
}

# Stage colors shown in the top annotation bar
stage_fill_map <- c(
  "Control"   = "#984ea3",
  "Farm"      = "#1b9e77",
  "Slaughter" = "#377eb8",
  "Market"    = "#ff7f00",
  "Other"     = "#D9D9D9"
)

# =========================================================
# 2. Helper functions
# =========================================================
first_existing_col <- function(df, candidates) {
  hit <- candidates[candidates %in% colnames(df)]
  if (length(hit) == 0) return(NA_character_)
  hit[1]
}

extract_taxon_from_taxonomy <- function(x, rank_prefix = "g__") {
  x <- as.character(x)
  x[is.na(x)] <- ""
  
  pattern <- paste0(rank_prefix, "([^;]+)")
  out <- str_match(x, pattern)[, 2]
  out[is.na(out) | out == ""] <- "Unclassified"
  out <- str_trim(out)
  out[out == "" | out == "NA" | out == "uncultured" | out == "unclassified"] <- "Unclassified"
  out
}

extract_day_num <- function(x) {
  d <- str_match(x, "D(\\d+)")[, 2]
  d <- suppressWarnings(as.numeric(d))
  d[is.na(d)] <- 999
  d
}

stage_name_from_group <- function(g) {
  g2 <- tolower(as.character(g))
  case_when(
    str_detect(g2, "^c_") ~ "Control",
    str_detect(g2, "^f_") ~ "Farm",
    str_detect(g2, "^s_") ~ "Slaughter",
    str_detect(g2, "^m_") ~ "Market",
    TRUE ~ "Other"
  )
}

detect_panel_from_meta <- function(group_vec, sample_type_vec) {
  g2 <- tolower(as.character(group_vec))
  s2 <- tolower(as.character(sample_type_vec))
  
  panel <- rep(NA_character_, length(g2))
  
  # A = human / worker
  panel[str_detect(s2, "worker|human")] <- "A"
  
  # B = chicken / carcass / feces / cecum / meat.
  panel[is.na(panel) & str_detect(s2, "chicken|carcass|feces|faeces|cecum|meat")] <- "B"
  
  # C = environment.
  panel[is.na(panel) & str_detect(s2, "environment|floor|hand|hook|knife|water|board")] <- "C"
  
  # Fall back to Group-based panel assignment
  panel[is.na(panel) & str_detect(g2, "_w_|human")] <- "A"
  panel[is.na(panel) & str_detect(g2, "^f_d|_c_|p_yl|carcass|chicken")] <- "B"
  panel[is.na(panel) & str_detect(g2, "_h_|_e_|_k_|sm|env")] <- "C"
  
  panel[is.na(panel)] <- "C"
  panel
}

collapse_top_taxa <- function(df_panel, top_n = 18, rank_col = "Taxon") {
  top_taxa <- df_panel %>%
    group_by(.data[[rank_col]]) %>%
    summarise(TotalAbund = sum(RelAbund, na.rm = TRUE), .groups = "drop") %>%
    arrange(desc(TotalAbund)) %>%
    slice_head(n = top_n) %>%
    pull(.data[[rank_col]])
  
  df_panel %>%
    mutate(Taxon2 = ifelse(.data[[rank_col]] %in% top_taxa, .data[[rank_col]], "Other")) %>%
    group_by(SampleID, Group, StageName, day_num, Taxon2) %>%
    summarise(RelAbund = sum(RelAbund, na.rm = TRUE), .groups = "drop") %>%
    rename(Taxon = Taxon2)
}

make_order_df <- function(df_panel) {
  sample_order <- df_panel %>%
    distinct(SampleID, Group, StageName, day_num) %>%
    mutate(
      stage_order = case_when(
        StageName == "Control"   ~ 0,
        StageName == "Farm"      ~ 1,
        StageName == "Slaughter" ~ 2,
        StageName == "Market"    ~ 3,
        TRUE ~ 9
      )
    ) %>%
    arrange(stage_order, day_num, Group, SampleID) %>%
    mutate(x = row_number())
  
  group_block <- sample_order %>%
    group_by(StageName, Group) %>%
    summarise(
      xmin = min(x) - 0.5,
      xmax = max(x) + 0.5,
      xmid = mean(range(x)),
      .groups = "drop"
    )
  
  stage_block <- sample_order %>%
    group_by(StageName) %>%
    summarise(
      xmin = min(x) - 0.5,
      xmax = max(x) + 0.5,
      xmid = mean(range(x)),
      .groups = "drop"
    )
  
  list(sample_order = sample_order, group_block = group_block, stage_block = stage_block)
}

# =========================================================
# 3. Read MAG abundance table
# =========================================================
mag_abund <- read.delim(MAG_ABUND_FP, check.names = FALSE, stringsAsFactors = FALSE)

cat("MAG abundance columns preview:\n")
print(head(colnames(mag_abund), 20))

colnames(mag_abund)[1] <- "MAG_ID"
sample_cols <- setdiff(colnames(mag_abund), "MAG_ID")

abund_long <- mag_abund %>%
  pivot_longer(
    cols = all_of(sample_cols),
    names_to = "SampleID",
    values_to = "Abundance"
  ) %>%
  mutate(
    SampleID = as.character(SampleID),
    Abundance = suppressWarnings(as.numeric(Abundance)),
    Abundance = replace_na(Abundance, 0)
  )

# =========================================================
# 4. Read MAG taxonomy table
# =========================================================
tax_df <- read.delim(TAX_FP, check.names = FALSE, stringsAsFactors = FALSE)

cat("Taxonomy columns detected:\n")
print(colnames(tax_df))

tax_mag_candidates <- c("MAG_bin", "user_genome", "MAG_ID", "MAG", "Bin", "bin", "Genome", "genome")
tax_mag_col <- if (FORCE_TAX_MAG_COL %in% colnames(tax_df)) FORCE_TAX_MAG_COL else first_existing_col(tax_df, tax_mag_candidates)
if (is.na(tax_mag_col)) stop("Cannot detect MAG ID column in taxonomy file.")

tax_use <- tax_df %>%
  rename(MAG_ID = !!tax_mag_col) %>%
  mutate(MAG_ID = as.character(MAG_ID))

# Prefer existing taxonomic-rank columns; otherwise parse from gtdb_taxonomy
family_col_candidates  <- c("Family", "family", "f")
genus_col_candidates   <- c("Genus", "genus", "g")
species_col_candidates <- c("Species", "species", "s")

family_col  <- first_existing_col(tax_use, family_col_candidates)
genus_col   <- first_existing_col(tax_use, genus_col_candidates)
species_col <- first_existing_col(tax_use, species_col_candidates)

taxonomy_col <- if (FORCE_TAXONOMY_COL %in% colnames(tax_use)) FORCE_TAXONOMY_COL else NA_character_

if (is.na(family_col) && !is.na(taxonomy_col)) {
  tax_use$Family <- extract_taxon_from_taxonomy(tax_use[[taxonomy_col]], "f__")
} else if (!is.na(family_col)) {
  tax_use$Family <- as.character(tax_use[[family_col]])
}

if (is.na(genus_col) && !is.na(taxonomy_col)) {
  tax_use$Genus <- extract_taxon_from_taxonomy(tax_use[[taxonomy_col]], "g__")
} else if (!is.na(genus_col)) {
  tax_use$Genus <- as.character(tax_use[[genus_col]])
}

if (is.na(species_col) && !is.na(taxonomy_col)) {
  tax_use$Species <- extract_taxon_from_taxonomy(tax_use[[taxonomy_col]], "s__")
} else if (!is.na(species_col)) {
  tax_use$Species <- as.character(tax_use[[species_col]])
}

tax_use <- tax_use %>%
  mutate(
    Family  = if_else(is.na(Family)  | Family  == "" | Family  == "NA", "Unclassified", Family),
    Genus   = if_else(is.na(Genus)   | Genus   == "" | Genus   == "NA", "Unclassified", Genus),
    Species = if_else(is.na(Species) | Species == "" | Species == "NA", "Unclassified", Species)
  ) %>%
  select(MAG_ID, Family, Genus, Species) %>%
  distinct()

# =========================================================
# 5. Read metadata / group table
# =========================================================
meta <- read_xlsx(GROUP_FP)

cat("Metadata columns detected:\n")
print(colnames(meta))

sample_col <- if (FORCE_SAMPLE_COL %in% colnames(meta)) FORCE_SAMPLE_COL else first_existing_col(meta, META_SAMPLE_CANDIDATES)
group_col  <- if (FORCE_GROUP_COL %in% colnames(meta)) FORCE_GROUP_COL else first_existing_col(meta, META_GROUP_CANDIDATES)
type_col   <- if (FORCE_TYPE_COL %in% colnames(meta)) FORCE_TYPE_COL else first_existing_col(meta, META_TYPE_CANDIDATES)
stage_col  <- if (FORCE_STAGE_COL %in% colnames(meta)) FORCE_STAGE_COL else first_existing_col(meta, META_STAGE_CANDIDATES)

if (is.na(sample_col) || is.na(group_col)) {
  stop("Cannot detect sample ID / group column in Group_302_all.xlsx")
}

meta2 <- meta %>%
  rename(
    SampleID = !!sample_col,
    Group = !!group_col
  ) %>%
  mutate(
    SampleID = as.character(SampleID),
    Group = as.character(Group)
  )

if (!is.na(type_col)) {
  meta2 <- meta2 %>% mutate(SampleTypeMeta = as.character(.data[[type_col]]))
} else {
  meta2$SampleTypeMeta <- ""
}

if (!is.na(stage_col)) {
  meta2 <- meta2 %>% mutate(StageMeta = as.character(.data[[stage_col]]))
} else {
  meta2$StageMeta <- ""
}

cat("\nUnique Sample type preview:\n")
print(sort(unique(meta2$SampleTypeMeta)))

cat("\nUnique Stages preview:\n")
print(sort(unique(meta2$StageMeta)))

# =========================================================
# 6. Merge abundance, taxonomy and metadata
# =========================================================
plot_df <- abund_long %>%
  left_join(tax_use, by = "MAG_ID") %>%
  left_join(meta2, by = "SampleID") %>%
  mutate(
    Group = if_else(is.na(Group) | Group == "", SampleID, Group),
    StageName = stage_name_from_group(Group)
  ) %>%
  filter(!is.na(Group))

# =========================================================
# 7. Assign samples to A/B/C plotting panels
# =========================================================
group_panel_map <- plot_df %>%
  distinct(Group, SampleTypeMeta) %>%
  mutate(
    Panel = detect_panel_from_meta(Group, SampleTypeMeta)
  )

plot_df <- plot_df %>%
  left_join(group_panel_map, by = c("Group", "SampleTypeMeta")) %>%
  mutate(
    day_num = extract_day_num(Group)
  )

cat("\nPanel counts:\n")
print(table(plot_df$Panel, useNA = "ifany"))

# =========================================================
# 8. Plotting function
# =========================================================
plot_one_panel <- function(df_in, rank_name = "Genus", out_prefix = "Fig", rank_out_dir = ".") {
  if (nrow(df_in) == 0) {
    message("No data for rank ", rank_name, " in file ", out_prefix)
    return(list(plot = NULL, color_map = NULL))
  }
  
  top_n <- TOP_N_TAXA[[rank_name]]
  
  df_rank <- df_in %>%
    transmute(
      SampleID   = SampleID,
      Group      = Group,
      StageName  = StageName,
      day_num    = day_num,
      Taxon      = .data[[rank_name]],
      Abundance  = Abundance
    )
  
  # Aggregate to the selected taxonomic rank and convert to relative abundance
  tax_abund <- df_rank %>%
    group_by(SampleID, Group, StageName, day_num, Taxon) %>%
    summarise(Abundance = sum(Abundance, na.rm = TRUE), .groups = "drop")
  
  sample_total <- tax_abund %>%
    group_by(SampleID, Group) %>%
    summarise(Total = sum(Abundance, na.rm = TRUE), .groups = "drop")
  
  tax_abund <- tax_abund %>%
    left_join(sample_total, by = c("SampleID", "Group")) %>%
    mutate(RelAbund = if_else(Total > 0, Abundance / Total * 100, 0))
  
  tax_panel <- collapse_top_taxa(tax_abund, top_n = top_n, rank_col = "Taxon")
  
  ord <- make_order_df(tax_panel)
  sample_order <- ord$sample_order
  group_block  <- ord$group_block
  stage_block  <- ord$stage_block
  
  tax_panel <- tax_panel %>%
    left_join(sample_order, by = c("SampleID", "Group", "StageName", "day_num"))
  
  taxa_levels <- tax_panel %>%
    group_by(Taxon) %>%
    summarise(TotalAbund = sum(RelAbund, na.rm = TRUE), .groups = "drop") %>%
    arrange(desc(TotalAbund)) %>%
    pull(Taxon)
  
  taxa_levels <- c(setdiff(taxa_levels, "Other"), intersect("Other", taxa_levels))
  tax_panel$Taxon <- factor(tax_panel$Taxon, levels = rev(taxa_levels))
  taxa_palette <- make_taxa_palette(taxa_levels)
  
  n_samples <- nrow(sample_order)
  width_use <- max(BASE_PDF_WIDTH, n_samples * WIDTH_PER_SAMPLE + EXTRA_WIDTH)
  
  fill_values <- taxa_palette
  extra_stage_cols <- stage_fill_map[setdiff(names(stage_fill_map), names(fill_values))]
  fill_values <- c(fill_values, extra_stage_cols)
  
  p <- ggplot(tax_panel, aes(x = x, y = RelAbund, fill = Taxon)) +
    geom_rect(
      data = group_block,
      aes(xmin = xmin, xmax = xmax, ymin = BOTTOM_BAR_YMIN, ymax = BOTTOM_BAR_YMAX),
      inherit.aes = FALSE,
      fill = "#F2F2F2",
      color = "#BDBDBD",
      linewidth = 0.4
    ) +
    geom_rect(
      data = stage_block,
      aes(xmin = xmin, xmax = xmax, ymin = TOP_BAR_YMIN, ymax = TOP_BAR_YMAX, fill = StageName),
      inherit.aes = FALSE,
      color = "#BDBDBD",
      linewidth = 0.5,
      show.legend = FALSE
    ) +
    geom_col(width = 0.92, color = NA) +
    geom_text(
      data = group_block,
      aes(x = xmid, y = (BOTTOM_BAR_YMIN + BOTTOM_BAR_YMAX) / 2, label = Group),
      inherit.aes = FALSE,
      size = GROUP_TEXT_SIZE,
      fontface = "bold"
    ) +
    geom_text(
      data = stage_block,
      aes(x = xmid, y = (TOP_BAR_YMIN + TOP_BAR_YMAX) / 2, label = StageName),
      inherit.aes = FALSE,
      size = STAGE_TEXT_SIZE,
      fontface = "bold"
    ) +
    scale_fill_manual(
      values = fill_values,
      breaks = taxa_levels,
      drop = FALSE
    ) +
    scale_x_continuous(
      breaks = NULL,
      labels = NULL,
      expand = c(0.003, 0.003)
    ) +
    scale_y_continuous(
      limits = c(Y_MIN, Y_MAX),
      breaks = c(0, 25, 50, 75, 100),
      expand = c(0, 0)
    ) +
    labs(
      x = NULL,
      y = "Relative abundance (%)",
      fill = rank_name
    ) +
    theme_bw(base_size = 11) +
    theme(
      panel.background = element_rect(fill = "white", color = NA),
      plot.background  = element_rect(fill = "white", color = NA),
      
      panel.grid.major.x = element_blank(),
      panel.grid.minor = element_blank(),
      panel.grid.major.y = element_line(color = "#E6E6E6", linewidth = 0.35),
      
      axis.text.x = element_blank(),
      axis.ticks.x = element_blank(),
      axis.text.y = element_text(size = AXIS_TEXT_Y_SIZE),
      axis.title.y = element_text(face = "bold", size = AXIS_TITLE_SIZE),
      
      legend.position = "bottom",
      legend.direction = "horizontal",
      legend.box = "horizontal",
      legend.title = element_text(face = "bold", size = LEGEND_TITLE_SIZE),
      legend.text = element_text(size = LEGEND_TEXT_SIZE),
      legend.key.size = unit(LEGEND_KEY_SIZE, "cm"),
      legend.box.margin = margin(LEGEND_BOX_MARGIN, 0, 0, 0),
      legend.margin = margin(LEGEND_MARGIN_T, 0, 0, 0),
      
      plot.margin = margin(10, 10, PLOT_MARGIN_B, 18)
    ) +
    guides(
      fill = guide_legend(
        nrow = LEGEND_NROW,
        byrow = LEGEND_BYROW,
        override.aes = list(alpha = 1)
      )
    )
  
  ggsave(
    file.path(rank_out_dir, paste0(out_prefix, ".pdf")),
    p,
    width = width_use,
    height = BASE_PDF_HEIGHT,
    device = cairo_pdf,
    limitsize = FALSE
  )
  
  ggsave(
    file.path(rank_out_dir, paste0(out_prefix, ".png")),
    p,
    width = width_use,
    height = BASE_PDF_HEIGHT,
    dpi = 600,
    limitsize = FALSE
  )
  
  color_map <- tibble(
    Rank = rank_name,
    Taxon = taxa_levels,
    Color = unname(taxa_palette[taxa_levels])
  )
  
  list(plot = p, color_map = color_map)
}

# =========================================================
# 9. Export figures by taxonomic rank
# =========================================================
for (rk in TAX_RANKS) {
  rank_dir <- file.path(OUT_DIR, rk)
  dir.create(rank_dir, showWarnings = FALSE, recursive = TRUE)
  
  df_A <- plot_df %>% filter(Panel == "A")
  df_B <- plot_df %>% filter(Panel == "B")
  df_C <- plot_df %>% filter(Panel == "C")
  
  res_A <- plot_one_panel(df_A, rank_name = rk, out_prefix = paste0("Fig_", rk, "_A_human"), rank_out_dir = rank_dir)
  res_B <- plot_one_panel(df_B, rank_name = rk, out_prefix = paste0("Fig_", rk, "_B_chicken"), rank_out_dir = rank_dir)
  res_C <- plot_one_panel(df_C, rank_name = rk, out_prefix = paste0("Fig_", rk, "_C_environment"), rank_out_dir = rank_dir)
  
  # Save color mapping tables
  color_map_list <- list()
  if (!is.null(res_A$color_map)) color_map_list[["A_human"]] <- res_A$color_map
  if (!is.null(res_B$color_map)) color_map_list[["B_chicken"]] <- res_B$color_map
  if (!is.null(res_C$color_map)) color_map_list[["C_environment"]] <- res_C$color_map
  
  color_map_all <- bind_rows(color_map_list, .id = "Panel")
  
  if (nrow(color_map_all) > 0) {
    write.xlsx(
      list(
        color_map_all = color_map_all,
        A_human = if (!is.null(res_A$color_map)) res_A$color_map else tibble(),
        B_chicken = if (!is.null(res_B$color_map)) res_B$color_map else tibble(),
        C_environment = if (!is.null(res_C$color_map)) res_C$color_map else tibble()
      ),
      file = file.path(rank_dir, paste0("Color_mapping_", rk, ".xlsx")),
      overwrite = TRUE
    )
  }
}

# =========================================================
# 10. Export sample-to-panel check table
# =========================================================
panel_map_out <- plot_df %>%
  distinct(SampleID, Group, StageName, SampleTypeMeta, Panel) %>%
  arrange(Panel, StageName, Group, SampleID)

write.xlsx(
  panel_map_out,
  file = file.path(OUT_DIR, "Sample_group_stage_panel_map.xlsx"),
  overwrite = TRUE
)

cat("\nDone. Files saved in:\n", OUT_DIR, "\n")