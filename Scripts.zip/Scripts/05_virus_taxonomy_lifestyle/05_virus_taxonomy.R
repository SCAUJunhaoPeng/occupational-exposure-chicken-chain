# =========================
# 01_virus_taxonomy.R (geNomad taxonomy + vOTU abundance)
# Input:
#   1) virus_95_75_10.tsv           (vOTU abundance table, Contig + samples...)
#   2) genomad_virus_taxonomy.tsv    (geNomad taxonomy, seq_name_ + lineage)
#   3) Group.xlsx                   (sample grouping: ID + Group)
# Output:
#   results_virus_taxonomy/virus_taxonomy_geNomad.pdf  (multi-page)
#     Page1: Class stacked bar (mean relative abundance)
#     Page2: Family stacked bar (mean relative abundance)
#     Page3: Combined (no legends)
# =========================

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(ggforce)
  library(RColorBrewer)
  library(ggthemes)
  library(patchwork)
  library(readxl)
})

# =========================
# 0) Inputs (defaults; also support CLI args)
# =========================
votu_file  <- "virus_95_75_10.tsv"
tax_file   <- "genomad_virus_taxonomy.tsv"
group_file <- "Group.xlsx"

# Usage:
#   Rscript 01_virus_taxonomy.R <votu.tsv> <genomad_tax.tsv> <Group.xlsx>
args <- commandArgs(trailingOnly = TRUE)
if (length(args) >= 1) votu_file  <- args[1]
if (length(args) >= 2) tax_file   <- args[2]
if (length(args) >= 3) group_file <- args[3]

stopifnot(file.exists(votu_file))
stopifnot(file.exists(tax_file))
stopifnot(file.exists(group_file))

outdir <- "results_virus_taxonomy"
dir.create(outdir, showWarnings = FALSE, recursive = TRUE)

# =========================
# Helpers: legend layout + pdf sizing
# =========================
pick_legend_ncol <- function(n_items) {
  if (n_items <= 18) return(1)
  if (n_items <= 36) return(2)
  if (n_items <= 54) return(3)
  return(4)
}

pick_legend_text_size <- function(n_items) {
  if (n_items <= 20) return(9)
  if (n_items <= 40) return(8)
  return(7)
}

calc_pdf_size <- function(n_groups, legend_rows_max) {
  # width: scale with number of groups
  w <- max(8.5, 0.65 * n_groups + 4)
  w <- min(w, 22)
  
  # height: allow legend on top + tilted x labels at bottom
  panel_h <- 3.4
  legend_h <- 0.35 + 0.22 * legend_rows_max
  xlab_h <- 0.9  # extra for tilted x labels
  single_page_h <- panel_h + legend_h + xlab_h + 0.6
  combined_page_h <- 2 * panel_h + xlab_h + 0.8
  
  h <- max(single_page_h, combined_page_h)
  h <- min(max(h, 7.5), 28)
  list(width = w, height = h)
}

# =========================
# 1) Read group (Group.xlsx: ID + Group)
# =========================
group <- read_excel(group_file) %>% as.data.frame()

if (!all(c("ID", "Group") %in% colnames(group))) {
  stop("Group.xlsx 必须包含两列：ID 和 Group（大小写一致）")
}

group <- group %>%
  transmute(samples = as.character(ID),
            group   = as.character(Group))

# group order: keep as in file
group_levels <- unique(group$group)

# =========================
# 2) Read vOTU table -> relative abundance (%)
# =========================
votu_raw <- read.delim(votu_file, sep = "\t", header = TRUE, check.names = FALSE)

# if first column isn't named Contig, force it
if (!("Contig" %in% colnames(votu_raw))) {
  colnames(votu_raw)[1] <- "Contig"
}

temp2 <- votu_raw[, -1, drop = FALSE]
temp2[] <- lapply(temp2, as.numeric)

col_sums <- colSums(temp2, na.rm = TRUE)
col_sums[col_sums == 0] <- 1
temp3 <- sweep(temp2, 2, col_sums, "/") * 100

votu_rea <- data.frame(Contig = votu_raw$Contig, temp3, check.names = FALSE)

votu_reaab <- votu_rea %>%
  pivot_longer(cols = -Contig, names_to = "samples", values_to = "abundance")

# =========================
# 3) Read geNomad taxonomy
# =========================
virus_tax <- read.delim(tax_file, sep = "\t", header = TRUE, check.names = FALSE)

contig_col <- if ("seq_name_" %in% names(virus_tax)) "seq_name_" else names(virus_tax)[1]
tax_col    <- if ("lineage"   %in% names(virus_tax)) "lineage"   else names(virus_tax)[ncol(virus_tax)]

virus_class <- virus_tax %>%
  transmute(
    Contig   = as.character(.data[[contig_col]]),
    taxonomy = as.character(.data[[tax_col]])
  )

virus_class_separated <- virus_class %>%
  mutate(taxonomy = ifelse(is.na(taxonomy), "", taxonomy)) %>%
  separate(
    taxonomy,
    into = c("Virus","Realm","Kingdom","Phylum","Class","Order","Family","Genus"),
    sep = ";",
    fill = "right",
    extra = "drop"
  ) %>%
  mutate(across(everything(), ~ trimws(.))) %>%
  mutate(across(everything(), ~ ifelse(is.na(.) | . == "", "Unassigned", .)))

# Merge abundance + taxonomy + group
votu_all <- votu_reaab %>%
  left_join(virus_class_separated, by = "Contig") %>%
  left_join(group, by = "samples") %>%
  mutate(across(c(Virus,Realm,Kingdom,Phylum,Class,Order,Family,Genus),
                ~ ifelse(is.na(.) | . == "", "Unassigned", .))) %>%
  filter(!is.na(group))  # keep only grouped samples

if (nrow(votu_all) == 0) {
  stop("合并后没有任何样本匹配到分组：请检查 vOTU 表列名是否与 Group.xlsx 的 ID 完全一致")
}

# =========================
# 4) Class plot (keep palette Set2 as much as possible)
# =========================
votu_class_mean <- votu_all %>%
  group_by(Class, samples, group) %>%
  summarise(sumrea = sum(abundance, na.rm = TRUE), .groups = "drop") %>%
  group_by(Class, group) %>%
  summarise(summean = mean(sumrea, na.rm = TRUE), .groups = "drop") %>%
  as.data.frame()

class_levels <- sort(unique(votu_class_mean$Class))
base_set2 <- brewer.pal(8, "Set2")
if (length(class_levels) <= length(base_set2)) {
  class_cols <- setNames(base_set2[seq_along(class_levels)], class_levels)
} else {
  class_cols <- setNames(colorRampPalette(base_set2)(length(class_levels)), class_levels)
}

n_class <- length(class_levels)
class_legend_ncol <- pick_legend_ncol(n_class)
class_legend_rows <- ceiling(n_class / class_legend_ncol)
class_legend_text <- pick_legend_text_size(n_class)

votu_class_mean$group <- factor(votu_class_mean$group, levels = group_levels)

class_p1 <- ggplot(votu_class_mean, aes(x = group, y = summean, fill = Class, color = Class)) +
  geom_col(position = "stack", width = 0.6) +
  facet_zoom(ylim = c(95.00, 100), zoom.size = 1) +
  scale_y_continuous(expand = c(0, 0)) +
  labs(x = "", y = "Relative Abundance(%)") +
  scale_color_manual(values = class_cols) +
  scale_fill_manual(values  = class_cols) +
  theme_test() +
  theme(
    panel.spacing.x = unit(0.2,"cm"),
    panel.spacing.y = unit(0.1,"cm"),
    axis.title = element_blank(),
    axis.title.y = element_text(colour="black", size = 12, margin = margin(r=5), face = "bold"),
    strip.text.x = element_text(size=9, color="black"),
    axis.text.y = element_text(color="black"),
    axis.text.x = element_text(color="black", angle = 45, hjust = 1, vjust = 1, size = 8),
    axis.ticks.x = element_blank(),
    legend.position = "top",
    legend.text = element_text(size = class_legend_text),
    plot.margin = unit(c(0.3, 0.3, 1.1, 0.3), "cm")
  ) +
  guides(fill = guide_legend(direction = "vertical", ncol = class_legend_ncol, byrow = TRUE))

# =========================
# 5) Family plot (keep palette Set3 as much as possible)
# =========================
votu_family_mean <- votu_all %>%
  group_by(Family, samples, group) %>%
  summarise(sumrea = sum(abundance, na.rm = TRUE), .groups = "drop") %>%
  group_by(Family, group) %>%
  summarise(summean = mean(sumrea, na.rm = TRUE), .groups = "drop") %>%
  as.data.frame()

family_levels <- sort(unique(votu_family_mean$Family))
base_set3 <- brewer.pal(9, "Set3")
if (length(family_levels) <= length(base_set3)) {
  family_cols <- setNames(base_set3[seq_along(family_levels)], family_levels)
} else {
  family_cols <- setNames(colorRampPalette(base_set3)(length(family_levels)), family_levels)
}

n_family <- length(family_levels)
family_legend_ncol <- pick_legend_ncol(n_family)
family_legend_rows <- ceiling(n_family / family_legend_ncol)
family_legend_text <- pick_legend_text_size(n_family)

votu_family_mean$group <- factor(votu_family_mean$group, levels = group_levels)

family_p1 <- ggplot(votu_family_mean, aes(x = group, y = summean, fill = Family, color = Family)) +
  geom_col(position = "stack", width = 0.6) +
  facet_zoom(ylim = c(95.00, 100), zoom.size = 1) +
  scale_y_continuous(expand = c(0, 0)) +
  labs(x = "", y = "Relative Abundance(%)") +
  scale_color_manual(values = family_cols) +
  scale_fill_manual(values  = family_cols) +
  theme_test() +
  theme(
    panel.spacing.x = unit(0.2,"cm"),
    panel.spacing.y = unit(0.1,"cm"),
    axis.title = element_blank(),
    axis.title.y = element_text(colour="black", size = 12, margin = margin(r=5), face = "bold"),
    strip.text.x = element_text(size=9, color="black"),
    axis.text.y = element_text(color="black"),
    axis.text.x = element_text(color="black", angle = 45, hjust = 1, vjust = 1, size = 8),
    axis.ticks.x = element_blank(),
    legend.position = "top",
    legend.text = element_text(size = family_legend_text),
    plot.margin = unit(c(0.3, 0.3, 1.1, 0.3), "cm")
  ) +
  guides(fill = guide_legend(direction = "vertical", ncol = family_legend_ncol, byrow = TRUE))

# =========================
# 6) Combined (no legends) + Save to auto-sized PDF
# =========================
combined_no_legend <- (class_p1 + theme(legend.position = "none")) /
  (family_p1 + theme(legend.position = "none")) +
  plot_layout(heights = c(1, 1))

# auto PDF size: based on groups + max legend rows
n_groups <- length(group_levels)
legend_rows_max <- max(class_legend_rows, family_legend_rows)
pdf_size <- calc_pdf_size(n_groups, legend_rows_max)

pdf_file <- file.path(outdir, "virus_taxonomy_geNomad.pdf")

# Multi-page PDF
pdf(pdf_file, width = pdf_size$width, height = pdf_size$height, onefile = TRUE, useDingbats = FALSE)
print(class_p1)
print(family_p1)
print(combined_no_legend)
dev.off()

message("Saved PDF: ", normalizePath(pdf_file))
message(sprintf("Auto page size (inches): width=%.2f, height=%.2f", pdf_size$width, pdf_size$height))
