## =========================
## 06_network_pro.R (fixed + optimized)
## - Fix group.x/group.y collision
## - Auto tilt x-axis + auto figure size
## - Optional Gephi export (needs abundance tables)
## =========================

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(RColorBrewer)
  library(broom)
  library(emmeans)
  library(readxl)
  library(readr)
  library(stringr)
  library(igraph)
})

## -------------------------
## User config
## -------------------------
out_dir <- "results_network_pro"
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

meta_file   <- "Group.xlsx"                 # ID + Group (required for your mode)
netpro_file <- "network_properties.csv"     # required
robust_file <- "robustness.csv"             # required

## Optional inputs for Gephi export
MAG_TSV    <- "mags_82_cols_rows.tsv"
VIRUS_TSV  <- "virus_82_cols_rows.tsv"
EXPORT_GEPHI <- TRUE
GEPHI_DIR <- file.path(out_dir, "gephi_exports")
dir.create(GEPHI_DIR, showWarnings = FALSE, recursive = TRUE)

## Network build params for Gephi (match your generator)
min_group_n     <- 2
min_prevalence  <- 4
rho_cut         <- 0.6
fdr_cut         <- 0.01
keep_negative   <- TRUE  # TRUE: keep both positive & negative edges (|rho|>cut) to match NC Fig4A
seed            <- 20260204

## Plot config
x_angle <- 45

## -------------------------
## Helpers
## -------------------------
fix_colnames <- function(df){
  nm <- names(df)
  nm <- trimws(nm)
  nm[is.na(nm) | nm == ""] <- paste0("X_blank_", seq_len(sum(is.na(nm) | nm == "")))
  names(df) <- make.names(nm, unique = TRUE)
  df
}

drop_index_col_if_needed <- function(df){
  if (ncol(df) < 2) return(df)
  first_name <- names(df)[1]
  if (first_name %in% c("X","X.1","X1","row","row.names","Unnamed..0")) {
    x <- df[[1]]
    ok_numeric <- suppressWarnings(all(!is.na(as.numeric(as.character(x)))))
    if (ok_numeric) {
      x_num <- suppressWarnings(as.numeric(as.character(x)))
      if (all(x_num == seq_along(x_num))) df <- df[, -1, drop = FALSE]
    }
  }
  df
}

read_csv_safe <- function(path){
  df <- read.csv(path, header = TRUE, check.names = TRUE, stringsAsFactors = FALSE)
  df <- fix_colnames(df)
  df <- drop_index_col_if_needed(df)
  df <- fix_colnames(df)
  df
}

theme_pub <- function(){
  theme_bw(base_size = 11) +
    theme(
      panel.grid = element_blank(),
      axis.text = element_text(color = "black"),
      strip.text = element_text(color = "black"),
      axis.text.x = element_text(angle = x_angle, hjust = 1, vjust = 1),
      plot.margin = unit(c(0.35,0.35,0.35,0.35), "cm")
    )
}

auto_plot_size <- function(n_groups, n_facets = 1, base_w = 7, base_h = 4.5){
  w <- max(base_w, 2.5 + 0.55 * n_groups)
  facet_rows <- if (n_facets <= 4) 1 else if (n_facets <= 8) 2 else 3
  h <- max(base_h, 2.8 + 2.2 * facet_rows)
  list(width = w, height = h)
}

pairwise_wilcox_bh_safe <- function(df, group_col = "group", value_col = "values", min_n_per_group = 2){
  df <- df %>% filter(!is.na(.data[[group_col]]), is.finite(.data[[value_col]]))
  cnt <- df %>% count(.data[[group_col]], name = "n") %>% filter(n >= min_n_per_group)
  df  <- df %>% filter(.data[[group_col]] %in% cnt[[group_col]])
  df[[group_col]] <- droplevels(as.factor(df[[group_col]]))
  
  if (nlevels(df[[group_col]]) < 2) {
    return(tibble(group1=character(), group2=character(), n1=integer(), n2=integer(),
                  p=double(), p.adj=double(), method=character()))
  }
  
  lev <- levels(df[[group_col]])
  comb <- t(combn(lev, 2))
  
  res <- lapply(seq_len(nrow(comb)), function(i){
    g1 <- comb[i,1]; g2 <- comb[i,2]
    x <- df %>% filter(.data[[group_col]] == g1) %>% pull(.data[[value_col]])
    y <- df %>% filter(.data[[group_col]] == g2) %>% pull(.data[[value_col]])
    n1 <- length(x); n2 <- length(y)
    
    pval <- tryCatch({
      suppressWarnings(wilcox.test(x, y, exact = FALSE)$p.value)
    }, error = function(e) NA_real_)
    
    tibble(group1=g1, group2=g2, n1=n1, n2=n2, p=pval, method="wilcox.test")
  }) %>% bind_rows()
  
  res %>% mutate(p.adj = p.adjust(p, method = "BH"))
}

## -------------------------
## Read inputs
## -------------------------
message("[Mode] Your Group.xlsx / one-way group comparisons")

if (!file.exists(netpro_file)) stop("Missing: ", netpro_file)
if (!file.exists(robust_file)) stop("Missing: ", robust_file)
if (!file.exists(meta_file))   stop("Missing: ", meta_file)

meta <- readxl::read_excel(meta_file) %>% as.data.frame()
if (!all(c("ID","Group") %in% colnames(meta))) {
  if (ncol(meta) < 2) stop("Group.xlsx needs at least two columns: ID and Group.")
  meta <- meta %>% rename(ID = 1, Group = 2)
}
meta <- meta %>%
  mutate(ID = as.character(ID), Group = as.character(Group)) %>%
  filter(!is.na(ID), !is.na(Group))

net_pro <- read_csv_safe(netpro_file)
rob <- read_csv_safe(robust_file)

## ---- Standardize net_pro ----
if (!("properties" %in% colnames(net_pro))) stop("network_properties.csv must contain: properties")
if (!("value" %in% colnames(net_pro))) stop("network_properties.csv must contain: value")

# Samples column (optional if group already exists)
if (!("Samples" %in% colnames(net_pro))) {
  cand <- intersect(colnames(net_pro), c("Sample","sample","ID","id","samples"))
  if (length(cand) >= 1) net_pro <- net_pro %>% rename(Samples = all_of(cand[1]))
}

# If net_pro already has group, keep it; else join from Group.xlsx via Samples
if ("group" %in% colnames(net_pro)) {
  net_pro <- net_pro %>% mutate(group = as.character(group))
} else {
  if (!("Samples" %in% colnames(net_pro))) {
    stop("network_properties.csv has no group and no Samples/ID column; cannot join Group.xlsx.")
  }
  net_pro <- net_pro %>%
    mutate(Samples = as.character(Samples)) %>%
    left_join(meta %>% transmute(Samples = ID, group = Group), by = "Samples")
}

# Handle group.x / group.y collision (the bug you hit)
if (!("group" %in% colnames(net_pro))) {
  gx <- "group.x" %in% colnames(net_pro)
  gy <- "group.y" %in% colnames(net_pro)
  if (gx && gy) {
    net_pro <- net_pro %>%
      mutate(group = dplyr::coalesce(as.character(group.x), as.character(group.y))) %>%
      select(-group.x, -group.y)
  } else if (gx) {
    net_pro <- net_pro %>% rename(group = group.x)
  } else if (gy) {
    net_pro <- net_pro %>% rename(group = group.y)
  }
}

if (!("group" %in% colnames(net_pro))) {
  stop("After processing, `group` column still missing in network_properties.csv. Please check column names.")
}

net_pro <- net_pro %>%
  mutate(value = suppressWarnings(as.numeric(value))) %>%
  filter(!is.na(group), !is.na(properties))

## ---- Standardize robustness ----
if (!("group" %in% colnames(rob))) stop("robustness.csv must contain column: group")

if (!("values" %in% colnames(rob))) {
  if ("value" %in% colnames(rob)) {
    rob <- rob %>% rename(values = value)
  } else {
    other_cols <- setdiff(colnames(rob), "group")
    if (length(other_cols) < 1) stop("robustness.csv must have values/value or wide numeric columns.")
    rob <- rob %>%
      pivot_longer(cols = all_of(other_cols), names_to = "rep", values_to = "values") %>%
      select(-rep)
  }
}
rob <- rob %>% mutate(values = suppressWarnings(as.numeric(values)))

## -------------------------
## Clean non-finite + QC reports
## -------------------------
net_pro_clean <- net_pro %>%
  mutate(is_finite = is.finite(value)) %>%
  filter(is_finite)

rob_clean <- rob %>%
  mutate(is_finite = is.finite(values)) %>%
  filter(is_finite)

qc_np <- net_pro %>%
  mutate(is_finite = is.finite(value)) %>%
  group_by(properties, group) %>%
  summarise(n_all=n(), n_finite=sum(is_finite), n_dropped=sum(!is_finite | is.na(value)), .groups="drop")
write.table(qc_np, file.path(out_dir, "QC_network_properties_nonfinite.tsv"),
            sep="\t", row.names=FALSE, quote=FALSE)

qc_rb <- rob %>%
  mutate(is_finite = is.finite(values)) %>%
  group_by(group) %>%
  summarise(n_all=n(), n_finite=sum(is_finite), n_dropped=sum(!is_finite | is.na(values)), .groups="drop")
write.table(qc_rb, file.path(out_dir, "QC_robustness_nonfinite.tsv"),
            sep="\t", row.names=FALSE, quote=FALSE)

## -------------------------
## Factor ordering
## -------------------------
group_levels <- unique(meta$Group)
# if robustness has groups not in meta, append them
group_levels <- c(group_levels, setdiff(unique(c(as.character(net_pro_clean$group), as.character(rob_clean$group))), group_levels))

net_pro_clean <- net_pro_clean %>% mutate(group = factor(group, levels = group_levels))
rob_clean     <- rob_clean %>% mutate(group = factor(group, levels = group_levels))

## Palette
n_g <- nlevels(droplevels(net_pro_clean$group))
pal_base <- RColorBrewer::brewer.pal(min(12, max(3, n_g)), "Paired")
pal <- colorRampPalette(pal_base)(n_g)

## properties order
prop_levels <- c("Nodes","Links","Average_K","Average_path_length","Connected_components","RM","Vulnerability")
prop_levels <- c(prop_levels, setdiff(unique(as.character(net_pro_clean$properties)), prop_levels))
net_pro_clean <- net_pro_clean %>% mutate(properties = factor(properties, levels = prop_levels))

## -------------------------
## Plot 1: Network properties
## -------------------------
p_net <- ggplot(net_pro_clean, aes(x = group, y = value, fill = group)) +
  geom_jitter(aes(color = group), alpha = 0.6, size = 1.8, width = 0.15) +
  stat_summary(fun.data = "mean_cl_normal", geom = "errorbar", width = 0.25, alpha = 0.75) +
  stat_summary(fun = "mean", geom = "point", size = 2.6, pch = 21) +
  scale_color_manual(values = pal) +
  scale_fill_manual(values = pal) +
  facet_wrap(~properties, nrow = 2, scales = "free_y") +
  labs(x = NULL, y = NULL) +
  theme_pub() +
  theme(legend.position = "none")

sz_net <- auto_plot_size(n_groups = n_g, n_facets = nlevels(net_pro_clean$properties), base_w = 8, base_h = 6)
ggsave(file.path(out_dir, "Fig_Network_properties_by_group.pdf"),
       p_net, width = sz_net$width, height = sz_net$height, units = "in")

## -------------------------
## Stats: per-property lm + emmeans(BH)
## -------------------------
run_lm_pairs <- function(df){
  df <- df %>% filter(is.finite(value), !is.na(group))
  df$group <- droplevels(df$group)
  if (nlevels(df$group) < 2) {
    return(list(coef=tibble(), anova=tibble(), diag=tibble(), pairs=tibble()))
  }
  m <- lm(value ~ group, data = df)
  emm <- emmeans(m, ~ group)
  pairs_tab <- as.data.frame(pairs(emm, adjust = "BH"))
  anova_tab <- broom::tidy(anova(m))
  coef_tab  <- broom::tidy(m)
  shapiro_p <- tryCatch(shapiro.test(resid(m))$p.value, error = function(e) NA_real_)
  diag_tab  <- tibble(n=nrow(df), AIC=AIC(m), shapiro_p=shapiro_p)
  list(coef=coef_tab, anova=anova_tab, diag=diag_tab, pairs=pairs_tab)
}

props <- levels(net_pro_clean$properties)
model_list <- lapply(props, function(pr){
  df <- net_pro_clean %>% filter(properties == pr)
  out <- run_lm_pairs(df)
  out$coef  <- out$coef  %>% mutate(properties = pr)
  out$anova <- out$anova %>% mutate(properties = pr)
  out$diag  <- out$diag  %>% mutate(properties = pr)
  out$pairs <- out$pairs %>% mutate(properties = pr)
  out
})

write.table(bind_rows(lapply(model_list, `[[`, "coef")),
            file.path(out_dir, "NetworkProperties_LM_coef.tsv"),
            sep="\t", row.names=FALSE, quote=FALSE)
write.table(bind_rows(lapply(model_list, `[[`, "anova")),
            file.path(out_dir, "NetworkProperties_LM_anova.tsv"),
            sep="\t", row.names=FALSE, quote=FALSE)
write.table(bind_rows(lapply(model_list, `[[`, "diag")),
            file.path(out_dir, "NetworkProperties_LM_diagnostics.tsv"),
            sep="\t", row.names=FALSE, quote=FALSE)
write.table(bind_rows(lapply(model_list, `[[`, "pairs")),
            file.path(out_dir, "NetworkProperties_Posthoc_pairs_BH.tsv"),
            sep="\t", row.names=FALSE, quote=FALSE)

## -------------------------
## Plot 2: Robustness
## -------------------------
n_g2 <- nlevels(droplevels(rob_clean$group))
p_rob <- ggplot(rob_clean, aes(x = group, y = values, fill = group)) +
  geom_boxplot(outlier.shape = NA) +
  geom_jitter(width = 0.12, size = 0.8, alpha = 0.45) +
  scale_fill_manual(values = pal) +
  labs(x = NULL, y = "Robustness") +
  theme_pub() +
  theme(legend.position = "none")

sz_rob <- auto_plot_size(n_groups = n_g2, n_facets = 1, base_w = 7, base_h = 4.5)
ggsave(file.path(out_dir, "Fig_Robustness_by_group.pdf"),
       p_rob, width = sz_rob$width, height = sz_rob$height, units = "in")

## -------------------------
## Robustness stats: Kruskal + safe pairwise Wilcox(BH)
## -------------------------
rob_for_test <- rob_clean %>%
  group_by(group) %>% filter(n() >= 2) %>% ungroup() %>%
  mutate(group = droplevels(group))

if (nlevels(rob_for_test$group) >= 2) {
  kw <- broom::tidy(kruskal.test(values ~ group, data = rob_for_test))
  write.table(kw, file.path(out_dir, "Robustness_Kruskal.tsv"),
              sep="\t", row.names=FALSE, quote=FALSE)
} else {
  write.table(tibble(note="Not enough groups with >=2 finite values for Kruskal test."),
              file.path(out_dir, "Robustness_Kruskal.tsv"),
              sep="\t", row.names=FALSE, quote=FALSE)
}

pw <- pairwise_wilcox_bh_safe(rob_for_test, group_col="group", value_col="values", min_n_per_group=2)
write.table(pw, file.path(out_dir, "Robustness_pairwise_wilcox_BH.tsv"),
            sep="\t", row.names=FALSE, quote=FALSE)

## -------------------------
## Optional: Export Gephi files (edge/node/gexf) per group
## -------------------------
if (EXPORT_GEPHI && file.exists(MAG_TSV) && file.exists(VIRUS_TSV)) {
  message("[Gephi] Abundance tables found. Exporting Gephi files...")
  
  mags_df  <- readr::read_tsv(MAG_TSV, show_col_types = FALSE)
  virus_df <- readr::read_tsv(VIRUS_TSV, show_col_types = FALSE)
  if (!("MAG" %in% colnames(mags_df))) colnames(mags_df)[1] <- "MAG"
  if (!("Contig" %in% colnames(virus_df))) colnames(virus_df)[1] <- "Contig"
  
  mags_mat <- as.data.frame(mags_df); rownames(mags_mat) <- mags_mat$MAG; mags_mat$MAG <- NULL
  virus_mat <- as.data.frame(virus_df); rownames(virus_mat) <- virus_mat$Contig; virus_mat$Contig <- NULL
  mags_mat[]  <- lapply(mags_mat,  function(x) as.numeric(as.character(x)))
  virus_mat[] <- lapply(virus_mat, function(x) as.numeric(as.character(x)))
  
  shared_ids <- Reduce(intersect, list(meta$ID, colnames(mags_mat), colnames(virus_mat)))
  if (length(shared_ids) == 0) {
    warning("[Gephi] No shared sample IDs between Group.xlsx and abundance matrices. Skip Gephi export.")
  } else {
    meta2 <- meta %>% filter(ID %in% shared_ids)
    mags_mat <- mags_mat[, shared_ids, drop=FALSE]
    virus_mat <- virus_mat[, shared_ids, drop=FALSE]
    
    build_edges_for_group <- function(sample_ids){
      n_samp <- length(sample_ids)
      if (n_samp < min_group_n) return(NULL)
      
      mag_g <- as.matrix(mags_mat[, sample_ids, drop=FALSE])
      vir_g <- as.matrix(virus_mat[, sample_ids, drop=FALSE])
      
      # adapt prevalence cutoff for small n
      prev_cut <- min(min_prevalence, n_samp)
      keep_mag <- rowSums(mag_g > 0, na.rm=TRUE) >= prev_cut
      keep_vir <- rowSums(vir_g > 0, na.rm=TRUE) >= prev_cut
      mag_g <- mag_g[keep_mag, , drop=FALSE]
      vir_g <- vir_g[keep_vir, , drop=FALSE]
      
      mag_log <- log10(mag_g + 1)
      vir_log <- log10(vir_g + 1)
      
      keep_mag2 <- apply(mag_log, 1, sd, na.rm=TRUE) > 0
      keep_vir2 <- apply(vir_log, 1, sd, na.rm=TRUE) > 0
      mag_log <- mag_log[keep_mag2, , drop=FALSE]
      vir_log <- vir_log[keep_vir2, , drop=FALSE]
      
      if (nrow(mag_log) < 1 || nrow(vir_log) < 1) return(NULL)
      
      X <- t(mag_log); Y <- t(vir_log)
      rmat <- suppressWarnings(cor(X, Y, method="spearman", use="pairwise.complete.obs"))
      
      # p/FDR:
      # - For n>=3: t-approx p-values + BH-FDR
      # - For n<3: df<=0, p/FDR undefined -> skip and use rho threshold only
      if (n_samp >= 3) {
        dfree <- n_samp - 2
        tstat <- rmat * sqrt(dfree / pmax(1e-12, 1 - rmat^2))
        pmat  <- 2 * pt(-abs(tstat), df=dfree)
        qvec  <- p.adjust(as.vector(pmat), method="BH")
        qmat  <- matrix(qvec, nrow=nrow(pmat), ncol=ncol(pmat), dimnames=dimnames(pmat))
      } else {
        qmat <- matrix(NA_real_, nrow=nrow(rmat), ncol=ncol(rmat), dimnames=dimnames(rmat))
      }

      if (n_samp >= 3) {
        if (keep_negative) {
          idx <- which(abs(rmat) > rho_cut & qmat < fdr_cut, arr.ind=TRUE)
        } else {
          idx <- which(rmat > rho_cut & qmat < fdr_cut, arr.ind=TRUE)
        }
      } else {
        # n<3: skip FDR, keep edges by rho threshold only
        if (keep_negative) {
          idx <- which(abs(rmat) > rho_cut, arr.ind=TRUE)
        } else {
          idx <- which(rmat > rho_cut, arr.ind=TRUE)
        }
      }
      if (nrow(idx) == 0) return(NULL)
      
      tibble(
        Source = rownames(rmat)[idx[,1]],
        Target = colnames(rmat)[idx[,2]],
        Rho    = rmat[idx],
        Sign   = ifelse(rmat[idx] > 0, "positive", "negative"),
        Link   = ifelse(rmat[idx] > 0, "Positive link", "Negative link"),
        Weight = abs(rmat[idx]),          # Gephi uses non-negative weights
        FDR    = if (n_samp >= 3) qmat[idx] else rep(NA_real_, length(rmat[idx]))   # optional: for QC
      ) %>% distinct()
    }
    
    set.seed(seed)
    for (gname in unique(meta2$Group)) {
      sids <- meta2 %>% filter(Group == gname) %>% pull(ID)
      edges <- build_edges_for_group(sids)
      if (is.null(edges)) next
      
      g_full <- igraph::graph_from_data_frame(edges, directed = FALSE)
      E(g_full)$weight <- edges$Weight
      # Add node attributes into GraphML (for coloring in Gephi)
      mag_set <- unique(edges$Source)
      V(g_full)$Type <- ifelse(V(g_full)$name %in% mag_set, "MAG", "vOTU")
      V(g_full)$Label <- V(g_full)$name
      # Ensure edge attributes are present in GraphML (Positive/Negative links)
      E(g_full)$Sign <- edges$Sign
      E(g_full)$Link <- edges$Link
      
      safe_g <- make.names(gname)
      write.csv(edges, file.path(GEPHI_DIR, paste0("edges_", safe_g, ".csv")), row.names=FALSE)
      
      nodes <- tibble(
        Id = V(g_full)$name,
        Type = ifelse(V(g_full)$name %in% edges$Source, "MAG", "vOTU"),
        Degree = degree(g_full),
        Betweenness = betweenness(g_full, directed=FALSE, normalized=TRUE),
        Closeness = closeness(g_full, normalized=TRUE)
      )
      write.csv(nodes, file.path(GEPHI_DIR, paste0("nodes_", safe_g, ".csv")), row.names=FALSE)
      write_graph(g_full, file.path(GEPHI_DIR, paste0("network_", safe_g, ".graphml")), format="graphml")
    }
    message("[Gephi] Export done: ", GEPHI_DIR)
  }
} else {
  message("[Gephi] Skip export (set EXPORT_GEPHI=TRUE and ensure mags_*.tsv & virus_*.tsv exist).")
}

sink(file.path(out_dir, "sessionInfo.txt"))
print(sessionInfo())
sink()

message("All outputs saved to: ", out_dir)

