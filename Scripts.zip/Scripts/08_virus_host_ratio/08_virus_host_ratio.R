## =========================================================
## 05_virus_host_ratio_restorePalette_singleHeatmap_focusFamilies_v2.R
##
## 功能：
## 1) 全部样本按 32 个 Group 分析 -> group32_all/
## 2) 全部样本按三大来源 group3 分析 -> group3_all/
## 3) Human feces / Chicken feces and chicken carcasses / Environment
##    三个子集分别单独分析，单独输出文件夹
## 4) 每个分析都输出：
##    - VHR 分布图（all / lytic / lysogenic） -> PDF
##    - ANOVA / emmeans / BH pairwise / compact letters -> TSV
##    - 相关性热图（Phylum / Family / Genus / Species） -> PDF
## 5) 热图恢复单图，不再分页
## 6) VHR 图：
##    - 恢复原始风格
##    - 散点颜色对应分组颜色
##    - 散点层栅格化（若安装 ggrastr）
##    - y 轴自动随数据范围变化，并强制显示上下限刻度
##    - 顶部增加每组 n=xx
##    - 顶部增加多重比较显著性字母（BH, emmeans）
## 7) 新增重点家族下钻分析：
##    - Enterobacteriaceae / Ruminococcaceae / Butyricicoccaceae
##    - 输出对应 family 的 genus / species 相关性热图与表格
##
## 输入文件：
##   Group_302_all.xlsx
##   virus_95_75_10.tsv
##   mags_95_75_10.tsv
##   virus_host_linkage.xlsx
##   votu_lysogenic_predict.csv
##
## 输出目录：
##   results_virus_host_ratio_split/
##     ├─ group32_all/
##     ├─ group3_all/
##     ├─ human_feces/
##     ├─ chicken_feces_and_carcasses/
##     └─ environment/
## =========================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(readxl)
  library(emmeans)
  library(broom)
  library(stringr)
  library(RColorBrewer)
  library(viridis)
  library(multcompView)
})

has_gghalves <- requireNamespace("gghalves", quietly = TRUE)
has_ggrastr  <- requireNamespace("ggrastr", quietly = TRUE)

## -----------------------------
## 0. 参数
## -----------------------------
root_out <- "results_virus_host_ratio_split"
dir.create(root_out, showWarnings = FALSE, recursive = TRUE)

group_file <- "Group_302_all.xlsx"
votu_file  <- "virus_95_75_10.tsv"
host_file  <- "mags_95_75_10.tsv"
link_file  <- "virus_host_linkage.xlsx"
life_file  <- "votu_lysogenic_predict.csv"

args <- commandArgs(trailingOnly = TRUE)
if (length(args) >= 1) group_file <- args[1]
if (length(args) >= 2) votu_file  <- args[2]
if (length(args) >= 3) host_file  <- args[3]
if (length(args) >= 4) link_file  <- args[4]
if (length(args) >= 5) life_file  <- args[5]

in_files <- c(group_file, votu_file, host_file, link_file, life_file)
missing_files <- in_files[!file.exists(in_files)]
if (length(missing_files) > 0) {
  stop("缺少输入文件：", paste(missing_files, collapse = ", "))
}

message("gghalves available: ", has_gghalves)
message("ggrastr available : ", has_ggrastr)

## -----------------------------
## 1. 工具函数
## -----------------------------
fix_bad_names <- function(df){
  nm <- names(df)
  nm[is.na(nm)] <- ""
  bad <- nm == ""
  if (any(bad)) {
    drop <- rep(FALSE, length(nm))
    for (i in which(bad)) {
      if (all(is.na(df[[i]]))) {
        drop[i] <- TRUE
      } else {
        nm[i] <- paste0("X", i)
      }
    }
    if (any(drop)) df <- df[, !drop, drop = FALSE]
    nm <- names(df)
    nm[is.na(nm)] <- ""
    if (any(nm == "")) nm[nm == ""] <- paste0("X", which(nm == ""))
  }
  names(df) <- make.unique(nm)
  df
}

drop_bad_sample_cols <- function(df, idcol = 1){
  if (ncol(df) <= idcol) return(df)
  mat <- df[, -(1:idcol), drop = FALSE]
  keep <- vapply(mat, function(x){
    x2 <- suppressWarnings(as.numeric(x))
    !(all(is.na(x2)) || sum(x2, na.rm = TRUE) == 0)
  }, logical(1))
  df[, c(rep(TRUE, idcol), keep), drop = FALSE]
}

to_rel_abund <- function(df, id_name){
  id <- as.character(df[[1]])
  mat <- as.matrix(df[, -1, drop = FALSE])
  mat <- apply(mat, 2, function(x) suppressWarnings(as.numeric(x)))
  cs <- colSums(mat, na.rm = TRUE)
  cs[cs == 0] <- NA_real_
  mat <- sweep(mat, 2, cs, "/") * 100
  mat[is.na(mat)] <- 0
  out <- data.frame(id, mat, check.names = FALSE)
  names(out)[1] <- id_name
  out
}

safe_inner_join <- function(x, y, by){
  fml <- names(formals(dplyr::inner_join))
  if ("relationship" %in% fml) {
    inner_join(x, y, by = by, relationship = "many-to-many")
  } else {
    inner_join(x, y, by = by)
  }
}

star_code <- function(p){
  ifelse(is.na(p), "",
         ifelse(p <= 0.001, "***",
                ifelse(p <= 0.01, "**",
                       ifelse(p <= 0.05, "*", ""))))
}

make_letters_from_pairs <- function(emm, adjust_method = "BH"){
  pw <- as.data.frame(pairs(emm, adjust = adjust_method))
  if (nrow(pw) == 0) return(NULL)
  
  levs <- emm@levels[[1]]
  pmat <- matrix(
    1,
    nrow = length(levs),
    ncol = length(levs),
    dimnames = list(levs, levs)
  )
  
  for (i in seq_len(nrow(pw))) {
    cn <- as.character(pw$contrast[i])
    pv <- pw$p.value[i]
    sp <- strsplit(cn, " - ", fixed = TRUE)[[1]]
    if (length(sp) == 2) {
      g1 <- sp[1]
      g2 <- sp[2]
      if (g1 %in% levs && g2 %in% levs) {
        pmat[g1, g2] <- pv
        pmat[g2, g1] <- pv
      }
    }
  }
  
  diag(pmat) <- 1
  
  letters <- multcompView::multcompLetters(
    pmat,
    threshold = 0.05
  )$Letters
  
  data.frame(
    group = names(letters),
    letters = unname(letters),
    stringsAsFactors = FALSE
  )
}

make_vhr_annotations <- function(df, xvar){
  if (nrow(df) == 0 || length(unique(df[[xvar]])) < 2) return(NULL)
  
  form <- as.formula(paste0("log10VHR ~ ", xvar))
  fit  <- lm(form, data = df)
  emm  <- emmeans(fit, as.formula(paste0("~ ", xvar)))
  
  n_tbl <- df %>%
    count(.data[[xvar]], name = "n") %>%
    rename(group = .data[[xvar]])
  
  emm_tbl <- as.data.frame(summary(emm))
  names(emm_tbl)[1] <- "group"
  
  let_tbl <- make_letters_from_pairs(emm, adjust_method = "BH")
  if (is.null(let_tbl)) return(NULL)
  
  out <- n_tbl %>%
    full_join(emm_tbl, by = "group") %>%
    full_join(let_tbl, by = "group")
  
  out
}

safe_cor_p <- function(x, y){
  ok <- is.finite(x) & is.finite(y)
  x <- x[ok]
  y <- y[ok]
  if (length(x) < 3 || length(unique(x)) < 2 || length(unique(y)) < 2) {
    return(c(r = NA_real_, p = NA_real_))
  }
  ct <- suppressWarnings(cor.test(x, y, method = "spearman"))
  c(r = unname(ct$estimate), p = ct$p.value)
}

theme_pub <- theme_bw(base_size = 11) +
  theme(
    axis.title.x = element_blank(),
    axis.title.y = element_text(colour = "black", size = 12, margin = margin(r = 5), face = "bold"),
    axis.text = element_text(color = "black"),
    axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1, size = 8),
    axis.ticks.x = element_blank(),
    legend.position = "none",
    plot.margin = unit(c(0.3, 0.3, 0.6, 0.3), "cm")
  )

save_pdf <- function(filename, plot, width, height){
  ggsave(
    filename = filename,
    plot = plot,
    width = width,
    height = height,
    units = "in",
    device = cairo_pdf,
    bg = "white"
  )
}

order_groups_supply_chain <- function(x) {
  x <- unique(as.character(x))
  get_day <- function(s) {
    m <- regexpr("(?i)(?:D|day)([0-9]+)", s, perl = TRUE)
    if (m[1] == -1) return(Inf)
    as.numeric(sub("(?i).*?(?:D|day)([0-9]+).*", "\\1", s, perl = TRUE))
  }
  stage_rank <- function(s) {
    if (grepl("^C_Human", s)) return(0)
    if (grepl("^F", s)) return(1)
    if (grepl("^S_E", s)) return(2)
    if (grepl("^S_P", s)) return(3)
    if (grepl("^S_C", s)) return(4)
    if (grepl("^S", s)) return(5)
    if (grepl("^M", s)) return(6)
    return(9)
  }
  df <- data.frame(group = x, stringsAsFactors = FALSE)
  df$stage <- vapply(df$group, stage_rank, numeric(1))
  df$day   <- vapply(df$group, get_day, numeric(1))
  df <- df[order(df$stage, df$day, df$group), , drop = FALSE]
  df$group
}

sanitize_filename <- function(x){
  x <- gsub("[^A-Za-z0-9_\\-]+", "_", x)
  x <- gsub("_+", "_", x)
  x
}

## -----------------------------
## 2. 颜色：阶段主色 + 饱和度/明度变化
## -----------------------------
stage_base_cols <- c(
  F = "#1b9e77",
  S = "#377eb8",
  M = "#ff7f00",
  C = "#984ea3"
)

lighten_color <- function(col, factor = 0.2){
  rgb_mat <- col2rgb(col) / 255
  rgb_new <- rgb_mat + (1 - rgb_mat) * factor
  rgb(rgb_new[1], rgb_new[2], rgb_new[3])
}

darken_color <- function(col, factor = 0.15){
  rgb_mat <- col2rgb(col) / 255
  rgb_new <- rgb_mat * (1 - factor)
  rgb(rgb_new[1], rgb_new[2], rgb_new[3])
}

get_stage_prefix <- function(g){
  if (grepl("^C", g)) return("C")
  if (grepl("^F", g)) return("F")
  if (grepl("^S", g)) return("S")
  if (grepl("^M", g)) return("M")
  "X"
}

make_stage_palette <- function(levels_vec){
  levels_vec <- as.character(levels_vec)
  stages <- vapply(levels_vec, get_stage_prefix, character(1))
  
  pal <- setNames(rep("#999999", length(levels_vec)), levels_vec)
  
  for (st in unique(stages)) {
    idx <- which(stages == st)
    lv_st <- levels_vec[idx]
    base_col <- stage_base_cols[st]
    n <- length(lv_st)
    
    if (is.na(base_col) || n == 0) next
    
    if (n == 1) {
      pal[lv_st] <- base_col
    } else {
      fac_seq <- seq(0.28, 0, length.out = n)
      cols_st <- vapply(fac_seq, function(f) lighten_color(base_col, factor = f), character(1))
      
      if (n >= 4) {
        half_idx <- seq_len(n)
        cols_st[half_idx > ceiling(n/2)] <- vapply(
          seq(0.05, 0.18, length.out = sum(half_idx > ceiling(n/2))),
          function(f) darken_color(base_col, factor = f),
          character(1)
        )
      }
      pal[lv_st] <- cols_st
    }
  }
  
  pal
}

group3_pal <- c(
  "Human_feces" = "#984ea3",
  "Chicken_feces_and_carcasses" = "#1b9e77",
  "Environment" = "#377eb8"
)

## -----------------------------
## 3. y轴：自动范围 + 强制显示上下限刻度
## -----------------------------
compute_auto_ylim_breaks <- function(y, n = 5){
  y <- y[is.finite(y)]
  if (length(y) == 0) {
    return(list(lims = c(-1, 1), breaks = c(-1, -0.5, 0, 0.5, 1)))
  }
  
  ymin <- min(y, na.rm = TRUE)
  ymax <- max(y, na.rm = TRUE)
  
  if (ymin == ymax) {
    pad <- max(0.5, abs(ymin) * 0.1)
    lims <- c(ymin - pad, ymax + pad)
  } else {
    rng <- ymax - ymin
    pad <- max(rng * 0.06, 0.15)
    lims <- c(ymin - pad, ymax + pad)
  }
  
  br <- pretty(lims, n = n)
  br <- unique(c(lims[1], br, lims[2]))
  br <- br[br >= lims[1] - 1e-9 & br <= lims[2] + 1e-9]
  br <- sort(unique(round(br, 3)))
  
  list(lims = lims, breaks = br)
}

make_left_points <- function(df, xvar, point_cap = 25000){
  if (nrow(df) == 0) return(df)
  out <- df
  if (nrow(out) > point_cap) {
    set.seed(123)
    out <- out[sample(seq_len(nrow(out)), point_cap), , drop = FALSE]
  }
  x_fac <- factor(out[[xvar]], levels = levels(out[[xvar]]))
  x_num <- as.numeric(x_fac)
  set.seed(123)
  out$x_left <- x_num - 0.18 + stats::runif(nrow(out), min = -0.08, max = 0.02)
  out
}

## -----------------------------
## 4. VHR 图：增加 n 与显著性字母
## -----------------------------
plot_vhr <- function(df, xvar, pal_map, ylab, point_cap = 25000){
  if (nrow(df) == 0) return(NULL)
  
  df[[xvar]] <- factor(df[[xvar]], levels = names(pal_map))
  df <- df %>% filter(!is.na(.data[[xvar]]), is.finite(log10VHR))
  if (nrow(df) == 0) return(NULL)
  
  y <- df$log10VHR
  y_rng <- diff(range(y, na.rm = TRUE))
  if (!is.finite(y_rng) || y_rng == 0) y_rng <- 1
  
  ann <- make_vhr_annotations(df, xvar)
  if (!is.null(ann)) {
    ann$group <- factor(ann$group, levels = names(pal_map))
  }
  
  ymin <- min(y, na.rm = TRUE)
  ymax <- max(y, na.rm = TRUE)
  bottom_pad <- max(0.15, y_rng * 0.06)
  top_pad    <- max(0.8,  y_rng * 0.22)
  
  y_lims <- c(ymin - bottom_pad, ymax + top_pad)
  y_breaks <- pretty(y_lims, n = 5)
  
  y_n      <- ymax + top_pad * 0.78
  y_letter <- ymax + top_pad * 0.48
  
  df_point <- make_left_points(df, xvar = xvar, point_cap = point_cap)
  
  p <- ggplot(df, aes(x = .data[[xvar]], y = log10VHR, fill = .data[[xvar]]))
  
  if (has_gghalves) {
    p <- p +
      gghalves::geom_half_violin(side = "r", alpha = 0.35, color = NA) +
      gghalves::geom_half_boxplot(
        side = "r",
        width = 0.2,
        outlier.size = 0.4,
        errorbar.draw = FALSE,
        linewidth = 0.3
      )
  } else {
    p <- p +
      geom_violin(alpha = 0.35, color = NA) +
      geom_boxplot(width = 0.2, outlier.size = 0.4, linewidth = 0.3)
  }
  
  if (has_ggrastr) {
    p <- p +
      ggrastr::rasterise(
        geom_point(
          data = df_point,
          aes(x = x_left, y = log10VHR, colour = .data[[xvar]]),
          inherit.aes = FALSE,
          shape = 16,
          size = 0.6,
          alpha = 0.42
        ),
        dpi = 300
      )
  } else {
    p <- p +
      geom_point(
        data = df_point,
        aes(x = x_left, y = log10VHR, colour = .data[[xvar]]),
        inherit.aes = FALSE,
        shape = 16,
        size = 0.6,
        alpha = 0.42
      )
  }
  
  if (!is.null(ann) && nrow(ann) > 0) {
    p <- p +
      geom_text(
        data = ann,
        aes(x = group, y = y_n, label = paste0("n=", n)),
        inherit.aes = FALSE,
        size = 3.1,
        color = "gray30"
      ) +
      geom_text(
        data = ann,
        aes(x = group, y = y_letter, label = letters),
        inherit.aes = FALSE,
        size = 3.4,
        color = "gray20"
      )
  }
  
  p +
    scale_fill_manual(values = pal_map) +
    scale_colour_manual(values = pal_map) +
    scale_x_discrete(drop = FALSE) +
    scale_y_continuous(
      limits = y_lims,
      breaks = y_breaks,
      expand = expansion(mult = c(0, 0))
    ) +
    labs(y = ylab) +
    coord_cartesian(clip = "off") +
    theme_pub +
    theme(
      plot.margin = unit(c(0.8, 0.3, 0.6, 0.3), "cm")
    )
}

## -----------------------------
## 5. 相关性热图
## -----------------------------
corr_table <- function(df, group_col, level_col, min_n = 4){
  group_sym <- rlang::sym(group_col)
  level_sym <- rlang::sym(level_col)
  
  tmp <- df %>%
    mutate(
      x = log10(TPM_v + 1e-12),
      y = log10(TPM_h + 1e-12)
    ) %>%
    filter(is.finite(x), is.finite(y)) %>%
    group_by(!!group_sym, !!level_sym) %>%
    summarise(
      n = n(),
      r = { tp <- safe_cor_p(x, y); tp[["r"]] },
      p = { tp <- safe_cor_p(x, y); tp[["p"]] },
      .groups = "drop"
    ) %>%
    filter(n >= min_n) %>%
    mutate(
      p_adj = p.adjust(p, method = "BH"),
      signif = star_code(p_adj)
    )
  
  tmp %>% tidyr::complete(!!group_sym, !!level_sym)
}

plot_corr_heat <- function(df, x_col, y_col){
  ggplot(df, aes(x = .data[[x_col]], y = .data[[y_col]], colour = r)) +
    geom_tile(fill = "white", color = "lightgray", linewidth = 0.5) +
    geom_point(aes(size = abs(r)), shape = 15, na.rm = TRUE) +
    geom_text(aes(label = signif), size = 3.5, color = "white", vjust = 0.7, na.rm = TRUE) +
    scale_colour_gradient2(
      low = "#FDE725",
      mid = "#35B779",
      high = "#440154",
      midpoint = 0,
      limits = c(-1, 1),
      na.value = "grey80",
      name = "r"
    ) +
    scale_size(range = c(1, 10), guide = "none") +
    labs(x = NULL, y = NULL) +
    theme_bw(base_size = 11) +
    theme(
      axis.text = element_text(color = "black"),
      axis.text.x = element_text(angle = 45, hjust = 1),
      plot.margin = unit(c(0.3, 0.3, 0.3, 0.3), "cm")
    )
}

## -----------------------------
## 6. 重点家族下钻：Genus / Species 相关性热图
## -----------------------------
save_focus_family_heatmaps <- function(df, xvar, out_dir,
                                       target_families = c("Enterobacteriaceae",
                                                           "Ruminococcaceae",
                                                           "Butyricicoccaceae")) {
  
  focus_root <- file.path(out_dir, "focus_families")
  dir.create(focus_root, showWarnings = FALSE, recursive = TRUE)
  
  x_n <- length(unique(as.character(df[[xvar]])))
  w_base <- max(8.5, 0.55 * x_n + 4)
  
  for (fam in target_families) {
    
    fam_dir <- file.path(focus_root, sanitize_filename(fam))
    dir.create(fam_dir, showWarnings = FALSE, recursive = TRUE)
    
    ## 1) Genus-level
    df_genus <- df %>%
      filter(!is.na(Family), Family == fam,
             !is.na(Genus), Genus != "", Genus != "unclassified") %>%
      mutate(Family_Genus = paste(Family, Genus, sep = "_"))
    
    if (nrow(df_genus) > 0) {
      corr_genus <- corr_table(df_genus, xvar, "Family_Genus", min_n = 6) %>%
        arrange(Family_Genus)
      
      write.table(
        corr_genus,
        file.path(fam_dir, paste0("Corr_Genus_", sanitize_filename(fam), ".tsv")),
        sep = "\t", row.names = FALSE, quote = FALSE
      )
      
      p_genus <- plot_corr_heat(corr_genus, xvar, "Family_Genus")
      save_pdf(
        file.path(fam_dir, paste0("Fig_Corr_heatmap_Genus_", sanitize_filename(fam), ".pdf")),
        p_genus,
        width = w_base,
        height = max(5.5, 0.35 * length(unique(corr_genus$Family_Genus)) + 2)
      )
    }
    
    ## 2) Species-level
    if ("Species" %in% colnames(df)) {
      df_species <- df %>%
        filter(!is.na(Family), Family == fam,
               !is.na(Genus), Genus != "", Genus != "unclassified",
               !is.na(Species), Species != "", Species != "unclassified") %>%
        mutate(Genus_Species = paste(Genus, Species, sep = "_"))
      
      if (nrow(df_species) > 0) {
        corr_species <- corr_table(df_species, xvar, "Genus_Species", min_n = 6) %>%
          arrange(Genus_Species)
        
        write.table(
          corr_species,
          file.path(fam_dir, paste0("Corr_Species_", sanitize_filename(fam), ".tsv")),
          sep = "\t", row.names = FALSE, quote = FALSE
        )
        
        p_species <- plot_corr_heat(corr_species, xvar, "Genus_Species")
        save_pdf(
          file.path(fam_dir, paste0("Fig_Corr_heatmap_Species_", sanitize_filename(fam), ".pdf")),
          p_species,
          width = w_base,
          height = max(6.5, 0.35 * length(unique(corr_species$Genus_Species)) + 2)
        )
      }
    }
    
    ## 3) family 本身的摘要表
    df_family_only <- df %>%
      filter(!is.na(Family), Family == fam)
    
    if (nrow(df_family_only) > 0) {
      corr_family_only <- corr_table(df_family_only, xvar, "Family", min_n = 6)
      
      write.table(
        corr_family_only,
        file.path(fam_dir, paste0("Corr_Family_summary_", sanitize_filename(fam), ".tsv")),
        sep = "\t", row.names = FALSE, quote = FALSE
      )
    }
  }
}

## -----------------------------
## 7. 统计函数
## -----------------------------
run_stats_bundle <- function(df, xvar, out_dir){
  fit_group <- function(df_sub, xvar, label){
    if (nrow(df_sub) < 3 || length(unique(df_sub[[xvar]])) < 2) return(NULL)
    
    df_sub[[xvar]] <- factor(df_sub[[xvar]], levels = unique(as.character(df_sub[[xvar]])))
    form <- as.formula(paste0("log10VHR ~ ", xvar))
    fit  <- lm(form, data = df_sub)
    emm  <- emmeans(fit, as.formula(paste0("~ ", xvar)))
    
    letters_tbl <- make_letters_from_pairs(emm, adjust_method = "BH")
    n_tbl <- df_sub %>%
      count(.data[[xvar]], name = "n") %>%
      rename(group = .data[[xvar]])
    
    if (!is.null(letters_tbl)) {
      letters_tbl <- n_tbl %>%
        full_join(letters_tbl, by = "group") %>%
        mutate(model_set = label, group_var = xvar)
    }
    
    list(
      anova   = broom::tidy(anova(fit)) %>% mutate(model_set = label, group_var = xvar),
      emmeans = as.data.frame(summary(emm)) %>% mutate(model_set = label, group_var = xvar),
      pairs   = as.data.frame(pairs(emm, adjust = "BH")) %>% mutate(model_set = label, group_var = xvar),
      letters = letters_tbl
    )
  }
  
  res_all  <- fit_group(df, xvar, "all")
  res_l    <- fit_group(df %>% filter(lifestyle == "lytic"), xvar, "lytic")
  res_lyso <- fit_group(df %>% filter(lifestyle == "lysogenic"), xvar, "lysogenic")
  
  all_res <- list(res_all, res_l, res_lyso)
  all_res <- all_res[!vapply(all_res, is.null, logical(1))]
  if (length(all_res) == 0) return(invisible(NULL))
  
  anova_tbl   <- bind_rows(lapply(all_res, `[[`, "anova"))
  emm_tbl     <- bind_rows(lapply(all_res, `[[`, "emmeans"))
  pairs_tbl   <- bind_rows(lapply(all_res, `[[`, "pairs"))
  letters_tbl <- bind_rows(lapply(all_res, `[[`, "letters"))
  
  write.table(anova_tbl, file.path(out_dir, "Group_ANOVA.tsv"),
              sep = "\t", row.names = FALSE, quote = FALSE)
  write.table(emm_tbl, file.path(out_dir, "Group_emmeans.tsv"),
              sep = "\t", row.names = FALSE, quote = FALSE)
  write.table(pairs_tbl, file.path(out_dir, "Group_pairs_BH.tsv"),
              sep = "\t", row.names = FALSE, quote = FALSE)
  
  if (nrow(letters_tbl) > 0) {
    write.table(letters_tbl, file.path(out_dir, "Group_letters_BH.tsv"),
                sep = "\t", row.names = FALSE, quote = FALSE)
  }
}

## -----------------------------
## 8. 图保存函数
## -----------------------------
save_vhr_set <- function(df, xvar, pal_map, out_dir){
  p_all <- plot_vhr(df, xvar, pal_map, "log10(VHR) (all linked vOTUs)")
  p_l   <- plot_vhr(df %>% filter(lifestyle == "lytic"), xvar, pal_map, "log10(VHR) (lytic vOTUs)")
  p_ly  <- plot_vhr(df %>% filter(lifestyle == "lysogenic"), xvar, pal_map, "log10(VHR) (lysogenic vOTUs)")
  
  nlev <- length(unique(as.character(df[[xvar]])))
  w <- max(8.5, 0.55 * nlev + 4)
  
  if (!is.null(p_all)) save_pdf(file.path(out_dir, "Fig_VHR_all.pdf"), p_all, width = w, height = 4.6)
  if (!is.null(p_l))   save_pdf(file.path(out_dir, "Fig_VHR_lytic.pdf"), p_l, width = w, height = 4.6)
  if (!is.null(p_ly))  save_pdf(file.path(out_dir, "Fig_VHR_lysogenic.pdf"), p_ly, width = w, height = 4.6)
}

save_corr_all_levels <- function(df, xvar, out_dir){
  x_n <- length(unique(as.character(df[[xvar]])))
  w_base <- max(8.5, 0.55 * x_n + 4)
  
  ## Phylum
  corr_phylum <- corr_table(df, xvar, "Phylum", min_n = 4)
  p1 <- plot_corr_heat(corr_phylum, xvar, "Phylum")
  save_pdf(file.path(out_dir, "Fig_Corr_heatmap_Phylum.pdf"), p1, width = w_base, height = 6.5)
  write.table(corr_phylum, file.path(out_dir, "Corr_Phylum.tsv"),
              sep = "\t", row.names = FALSE, quote = FALSE)
  
  ## Family
  df_family <- df %>%
    filter(!is.na(Family), Family != "", Family != "unclassified") %>%
    mutate(Phylum_Family = paste(Phylum, Family, sep = "_"))
  corr_family <- corr_table(df_family, xvar, "Phylum_Family", min_n = 6)
  p2 <- plot_corr_heat(corr_family, xvar, "Phylum_Family")
  save_pdf(file.path(out_dir, "Fig_Corr_heatmap_Family.pdf"), p2, width = w_base, height = 10)
  write.table(corr_family, file.path(out_dir, "Corr_Family.tsv"),
              sep = "\t", row.names = FALSE, quote = FALSE)
  
  ## Genus
  df_genus <- df %>%
    filter(!is.na(Genus), Genus != "", Genus != "unclassified") %>%
    mutate(Family_Genus = paste(Family, Genus, sep = "_"))
  corr_genus <- corr_table(df_genus, xvar, "Family_Genus", min_n = 8)
  p3 <- plot_corr_heat(corr_genus, xvar, "Family_Genus")
  save_pdf(file.path(out_dir, "Fig_Corr_heatmap_Genus.pdf"), p3, width = w_base, height = 12)
  write.table(corr_genus, file.path(out_dir, "Corr_Genus.tsv"),
              sep = "\t", row.names = FALSE, quote = FALSE)
  
  ## Species
  if ("Species" %in% colnames(df)) {
    df_species <- df %>%
      filter(!is.na(Species), Species != "", Species != "unclassified") %>%
      mutate(Genus_Species = paste(Genus, Species, sep = "_"))
    
    if (nrow(df_species) > 0) {
      corr_species <- corr_table(df_species, xvar, "Genus_Species", min_n = 10) %>%
        arrange(Genus_Species)
      
      p4 <- plot_corr_heat(corr_species, xvar, "Genus_Species")
      save_pdf(file.path(out_dir, "Fig_Corr_heatmap_Species.pdf"), p4, width = w_base, height = 14)
      write.table(corr_species, file.path(out_dir, "Corr_Species.tsv"),
                  sep = "\t", row.names = FALSE, quote = FALSE)
    }
  }
}

## -----------------------------
## 9. 总运行函数
## -----------------------------
run_one_analysis <- function(df_sub, xvar, out_dir, use_group_order = TRUE, fixed_levels = NULL, fixed_pal = NULL){
  dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)
  
  if (nrow(df_sub) == 0) {
    message("跳过空数据集：", out_dir)
    return(invisible(NULL))
  }
  
  if (is.null(fixed_levels)) {
    levels_now <- if (use_group_order) order_groups_supply_chain(df_sub[[xvar]]) else unique(as.character(df_sub[[xvar]]))
  } else {
    levels_now <- fixed_levels[fixed_levels %in% unique(as.character(df_sub[[xvar]]))]
  }
  
  df_sub[[xvar]] <- factor(df_sub[[xvar]], levels = levels_now)
  pal_now <- if (is.null(fixed_pal)) make_stage_palette(levels_now) else fixed_pal[levels_now]
  
  write.table(df_sub, file.path(out_dir, "VHR_longdata.tsv"),
              sep = "\t", row.names = FALSE, quote = FALSE)
  
  save_vhr_set(df_sub, xvar, pal_now, out_dir)
  run_stats_bundle(df_sub, xvar, out_dir)
  save_corr_all_levels(df_sub, xvar, out_dir)
  
  save_focus_family_heatmaps(
    df = df_sub,
    xvar = xvar,
    out_dir = out_dir,
    target_families = c("Enterobacteriaceae",
                        "Ruminococcaceae",
                        "Butyricicoccaceae")
  )
}

## -----------------------------
## 10. 读取 group 表
## -----------------------------
grp <- read_excel(group_file) %>%
  as.data.frame() %>%
  fix_bad_names()

if (!all(c("ID", "Group", "Sample type") %in% colnames(grp))) {
  stop("Group_302_all.xlsx 必须至少包含列：ID, Group, Sample type")
}

group <- grp %>%
  transmute(
    samples = as.character(ID),
    group = as.character(Group),
    sample_type = as.character(`Sample type`)
  ) %>%
  mutate(
    group3 = case_when(
      sample_type == "Human feces" ~ "Human_feces",
      sample_type == "Chicken feces and chicken carcasses" ~ "Chicken_feces_and_carcasses",
      sample_type == "Environment" ~ "Environment",
      TRUE ~ "Other"
    )
  )

## -----------------------------
## 11. 读取丰度表
## -----------------------------
votu_raw <- read.table(
  votu_file, sep = "\t", header = TRUE, check.names = FALSE,
  quote = "", comment.char = "", fill = TRUE
) %>%
  fix_bad_names() %>%
  drop_bad_sample_cols(idcol = 1)

host_raw <- read.table(
  host_file, sep = "\t", header = TRUE, check.names = FALSE,
  quote = "", comment.char = "", fill = TRUE
) %>%
  fix_bad_names() %>%
  drop_bad_sample_cols(idcol = 1)

if (!("Contig" %in% colnames(votu_raw))) colnames(votu_raw)[1] <- "Contig"
if (!("MAG" %in% colnames(host_raw)) && !("Genome" %in% colnames(host_raw))) colnames(host_raw)[1] <- "Genome"
if ("MAG" %in% colnames(host_raw)) colnames(host_raw)[1] <- "Genome"

votu_rea <- to_rel_abund(votu_raw, "Contig")
host_rea <- to_rel_abund(host_raw, "Genome")

v_long <- votu_rea %>%
  pivot_longer(-Contig, names_to = "samples", values_to = "TPM_v") %>%
  mutate(TPM_v = as.numeric(TPM_v))

h_long <- host_rea %>%
  pivot_longer(-Genome, names_to = "samples", values_to = "TPM_h") %>%
  mutate(TPM_h = as.numeric(TPM_h))

## -----------------------------
## 12. linkage 与 lifestyle
## -----------------------------
linkage <- read_excel(link_file, sheet = 1) %>%
  as.data.frame() %>%
  fix_bad_names()

need_cols <- c("Contig", "Genome", "Phylum", "Family", "Genus")
miss_cols <- setdiff(need_cols, colnames(linkage))
if (length(miss_cols) > 0) {
  stop("virus_host_linkage.xlsx 缺少列：", paste(miss_cols, collapse = ", "))
}

if (!("Species" %in% colnames(linkage))) {
  linkage$Species <- "unclassified"
}

life_raw <- read.csv(life_file, header = TRUE, check.names = FALSE) %>%
  fix_bad_names()

if (!("Contig" %in% colnames(life_raw))) {
  stop("votu_lysogenic_predict.csv 必须包含 Contig 列")
}

life_map <- life_raw %>%
  transmute(
    Contig = as.character(Contig),
    lifestyle = case_when(
      "Pred" %in% colnames(life_raw) & tolower(Pred) %in% c("temperate", "lysogenic") ~ "lysogenic",
      "Pred" %in% colnames(life_raw) & tolower(Pred) %in% c("virulent", "lytic") ~ "lytic",
      TRUE ~ "unknown"
    )
  )

## -----------------------------
## 13. 合并计算 VHR
## -----------------------------
dat <- linkage %>%
  distinct(Contig, Genome, Phylum, Family, Genus, Species, .keep_all = TRUE) %>%
  safe_inner_join(v_long, by = "Contig") %>%
  filter(TPM_v > 0) %>%
  safe_inner_join(h_long %>% filter(TPM_h > 0), by = c("Genome", "samples")) %>%
  left_join(group, by = "samples") %>%
  left_join(life_map, by = "Contig") %>%
  mutate(
    Phylum  = if_else(is.na(Phylum)  | Phylum  == "", "unclassified", as.character(Phylum)),
    Family  = if_else(is.na(Family)  | Family  == "", "unclassified", as.character(Family)),
    Genus   = if_else(is.na(Genus)   | Genus   == "", "unclassified", as.character(Genus)),
    Species = if_else(is.na(Species) | Species == "", "unclassified", as.character(Species)),
    lifestyle = if_else(is.na(lifestyle), "unknown", lifestyle),
    VHR = TPM_v / TPM_h,
    log10VHR = log10(VHR)
  ) %>%
  filter(!is.na(group), !is.na(group3))

if (nrow(dat) == 0) {
  stop("合并后没有有效数据，请检查样本名和 linkage 是否匹配。")
}

## -----------------------------
## 14. 跑 5 套分析
## -----------------------------
group3_levels <- c("Human_feces", "Chicken_feces_and_carcasses", "Environment")

## 14.1 全部样本按 32 组
run_one_analysis(
  df_sub = dat,
  xvar = "group",
  out_dir = file.path(root_out, "group32_all"),
  use_group_order = TRUE
)

## 14.2 全部样本按 group3
run_one_analysis(
  df_sub = dat %>% filter(group3 %in% group3_levels),
  xvar = "group3",
  out_dir = file.path(root_out, "group3_all"),
  use_group_order = FALSE,
  fixed_levels = group3_levels,
  fixed_pal = group3_pal
)

## 14.3 Human feces 子集
run_one_analysis(
  df_sub = dat %>% filter(group3 == "Human_feces"),
  xvar = "group",
  out_dir = file.path(root_out, "human_feces"),
  use_group_order = TRUE
)

## 14.4 Chicken feces and chicken carcasses 子集
run_one_analysis(
  df_sub = dat %>% filter(group3 == "Chicken_feces_and_carcasses"),
  xvar = "group",
  out_dir = file.path(root_out, "chicken_feces_and_carcasses"),
  use_group_order = TRUE
)

## 14.5 Environment 子集
run_one_analysis(
  df_sub = dat %>% filter(group3 == "Environment"),
  xvar = "group",
  out_dir = file.path(root_out, "environment"),
  use_group_order = TRUE
)

message("全部完成，输出目录：", root_out)