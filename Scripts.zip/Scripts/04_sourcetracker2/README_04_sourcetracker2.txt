04_sourcetracker2.R

Purpose
-------
This script generates scatterpie-style SourceTracker2 source-attribution panels for worker-associated microbiota in a chicken supply-chain study. It visualizes the contribution of source groups to worker sink groups across farm, slaughter and market stages.

Required input
--------------
Place the following file in the same folder as the script before running it:

- 04_megamatrix_piechart.tsv

Expected columns in the input table
-----------------------------------
The input table should contain:

- SinkGroup: worker-associated sink group
- SourceGroup: candidate source group
- SourceInfluence: SourceTracker2-derived source contribution
- Taxon columns: relative contributions of taxa used as pie slices

Main outputs
------------
The script creates the folder:

- 04_megamatrix_piechart/

and writes PDF and high-resolution PNG files for:

- Farm worker sink groups
- Slaughter worker sink groups
- Market worker sink groups
- Panels including Unknown sources
- Panels retaining only known sources

R packages
----------
The script requires the following R packages:

- tidyverse
- scatterpie
- ggforce
- grid

How to run
----------
From the folder containing the script and input table, run:

Rscript 04_sourcetracker2.R

Suggested GitHub location
-------------------------
scripts/04_sourcetracker2/

Recommended files in this folder
--------------------------------
- 04_sourcetracker2.R
- README.txt

Notes
-----
SourceInfluence is mapped to pie radius. Taxon columns define the internal composition of each pie chart. The script automatically collapses low-abundance taxa into Other and exports panels for both known-only and known-plus-Unknown source configurations.
