# =========================================================
# 04_sourcetracker2.R
#
# Purpose:
#   Generate scatterpie-style SourceTracker2 source-attribution panels
#   for worker-associated microbiota across farm, slaughter and market
#   stages of the chicken supply chain.
#
# Required input:
#   04_megamatrix_piechart.tsv
#
# Expected input columns:
#   SinkGroup, SourceGroup, SourceInfluence, and taxon abundance columns
#
# Main outputs:
#   PDF and PNG panels saved in 04_megamatrix_piechart/
#
# Notes:
#   The script produces panels with and without the Unknown source group.
#   SourceInfluence controls pie radius, while taxon columns define pie slices.
# =========================================================

suppressPackageStartupMessages({
  library(tidyverse)
  library(scatterpie)
  library(ggforce)
  library(grid)
})

# =========================================================
# input / output
# =========================================================
PIE_FP  <- "04_megamatrix_piechart.tsv"
OUT_DIR <- "04_megamatrix_piechart"
dir.create(OUT_DIR, showWarnings = FALSE, recursive = TRUE)

if (!file.exists(PIE_FP)) stop("Cannot find fixed megamatrix: ", PIE_FP)

# =========================================================
# parameters
# Radius scaling: enlarge differences in SourceInfluence values
# =========================================================
TOP_N_TAXA        <- 12
MIN_RADIUS        <- 0.015
RADIUS_SCALE      <- 0.75
RADIUS_POWER      <- 1.0
RING_N            <- 5
BASE_SIZE         <- 11
USE_CAIRO_PDF     <- TRUE

# Label positions
TOP_LABEL_MULT    <- 1.18
BOTTOM_LABEL_MULT <- 1.16
LEFT_LABEL_MULT   <- 1.18
RIGHT_LABEL_MULT  <- 1.18

# =========================================================
# read
# =========================================================
df <- read.delim(PIE_FP, check.names = FALSE, stringsAsFactors = FALSE)
df$SourceInfluence <- suppressWarnings(as.numeric(df$SourceInfluence))
df <- df %>% filter(!is.na(SourceInfluence))

# =========================================================
# Sink groups
# =========================================================
farm_sinks      <- c("F_W_D1","F_W_D31","F_W_D57")
slaughter_sinks <- c("S_E_W_D59","S_C_W_D59")
market_sinks    <- c("M_W_D60")

# =========================================================
# Source order
# =========================================================
farm_sources <- c(
  "F_D1","F_D31","F_D57",
  "F_F_D1","F_F_D31","F_F_D57",
  "F_W_H_D1","F_W_H_D31","F_W_H_D57",
  "Unknown"
)

slaughter_sources <- c(
  "S_E_C_D59","S_E_H_D59","S_P_YL_D59",
  "S_P_C_D59","S_C_C_D59","S_C_H_D59","S_C_K_D59",
  "Unknown"
)

market_sources <- c(
  "M_E_D60","M_SmCB_D60","M_SmCL_D60","M_SmWC_D60",
  "Unknown"
)

# =========================================================
# taxa columns
# =========================================================
taxa_cols_all <- setdiff(colnames(df), c("SinkGroup","SourceGroup","SourceInfluence"))

taxa_order <- df %>%
  select(all_of(taxa_cols_all)) %>%
  summarise(across(everything(), ~sum(.x, na.rm = TRUE))) %>%
  pivot_longer(cols = everything(), names_to = "Taxon", values_to = "Total") %>%
  arrange(desc(Total)) %>%
  pull(Taxon)

taxa_keep <- head(setdiff(taxa_order, "Other"), TOP_N_TAXA)
taxa_cols <- c(taxa_keep, "Other")

# =========================================================
# palette
# =========================================================
base_palette <- c(
  "#D8CBE2", "#CFAFD0", "#C18CBC", "#9E4C92",
  "#2D6FB7", "#7FAEDB", "#A39BCB", "#8E87C2",
  "#5B2D91", "#6EAEB1", "#9CC15B", "#C8BE52",
  "#DFC07A", "#A86D09", "#B77A18", "#F0AD38",
  "#F0902C", "#F00000", "#B5120D", "#7B160C",
  "#C5288D", "#D98ABD", "#E3C5DF", "#F1DFEE",
  "#DEE8A0", "#CFE08E", "#38A65A", "#005B2E"
)

if (length(taxa_cols) > length(base_palette)) {
  base_palette <- c(base_palette, rep("#BDBDBD", length(taxa_cols) - length(base_palette)))
}

taxa_palette <- setNames(base_palette[seq_along(taxa_cols)], taxa_cols)
taxa_palette["Other"] <- "#B7B7B7"

# =========================================================
# helper: collapse taxa
# =========================================================
collapse_taxa_to_other <- function(dat) {
  other_cols <- setdiff(taxa_cols_all, taxa_keep)
  
  dat2 <- dat %>%
    mutate(
      Other = if (length(other_cols) > 0) {
        rowSums(across(all_of(other_cols)), na.rm = TRUE)
      } else {
        if ("Other" %in% colnames(dat)) dat$Other else 0
      }
    ) %>%
    select(SinkGroup, SourceGroup, SourceInfluence, all_of(taxa_keep), Other)
  
  dat2
}

# =========================================================
# helper: background circles
# =========================================================
make_circle_data <- function(sink_levels, source_levels, r_max, ring_n = 5) {
  expand.grid(
    SinkGroup = sink_levels,
    SourceGroup = source_levels,
    ring_id = seq_len(ring_n),
    stringsAsFactors = FALSE
  ) %>%
    as_tibble() %>%
    mutate(
      SinkGroup   = factor(SinkGroup, levels = sink_levels),
      SourceGroup = factor(SourceGroup, levels = source_levels),
      x0 = 0,
      y0 = 0,
      r  = r_max * ring_id / ring_n
    )
}

make_cross_data <- function(sink_levels, source_levels, r_max) {
  base <- expand.grid(
    SinkGroup = sink_levels,
    SourceGroup = source_levels,
    stringsAsFactors = FALSE
  ) %>%
    as_tibble() %>%
    mutate(
      SinkGroup   = factor(SinkGroup, levels = sink_levels),
      SourceGroup = factor(SourceGroup, levels = source_levels)
    )
  
  horiz <- base %>%
    mutate(x = -r_max, xend = r_max, y = 0, yend = 0)
  
  vert <- base %>%
    mutate(x = 0, xend = 0, y = -r_max, yend = r_max)
  
  list(h = horiz, v = vert)
}

# =========================================================
# helper: prepare panel
# =========================================================
prep_panel <- function(dat, sink_levels, source_levels, keep_unknown = TRUE) {
  d <- dat %>%
    filter(SinkGroup %in% sink_levels, SourceGroup %in% source_levels)
  
  if (!keep_unknown) {
    d <- d %>% filter(SourceGroup != "Unknown")
    source_levels <- setdiff(source_levels, "Unknown")
  }
  
  d <- collapse_taxa_to_other(d)
  
  d <- d %>%
    mutate(
      SinkGroup   = factor(SinkGroup, levels = sink_levels),
      SourceGroup = factor(SourceGroup, levels = source_levels),
      x = 0,
      y = 0,
      r = pmax((pmax(SourceInfluence, 0)^RADIUS_POWER) * RADIUS_SCALE, MIN_RADIUS)
    ) %>%
    filter(!is.na(SinkGroup), !is.na(SourceGroup))
  
  # Add filler rows for missing facet panels
  all_panels <- expand.grid(
    SinkGroup = sink_levels,
    SourceGroup = source_levels,
    stringsAsFactors = FALSE
  ) %>%
    as_tibble() %>%
    mutate(
      SinkGroup   = factor(SinkGroup, levels = sink_levels),
      SourceGroup = factor(SourceGroup, levels = source_levels)
    )
  
  missing_panels <- anti_join(
    all_panels,
    d %>% distinct(SinkGroup, SourceGroup),
    by = c("SinkGroup", "SourceGroup")
  )
  
  if (nrow(missing_panels) > 0) {
    filler <- missing_panels %>%
      mutate(
        SourceInfluence = 0,
        x = 0,
        y = 0,
        r = MIN_RADIUS
      )
    
    for (tx in taxa_keep) filler[[tx]] <- 0
    filler[["Other"]] <- 1
    
    d <- bind_rows(d, filler)
  }
  
  list(
    data = d,
    sink_levels = sink_levels,
    source_levels = source_levels
  )
}

# =========================================================
# helper: plot
# =========================================================
plot_one_panel <- function(prep_obj, title_lab, pdf_name, png_name,
                           width = 12, height = 5) {
  dat <- prep_obj$data
  sink_levels <- prep_obj$sink_levels
  source_levels <- prep_obj$source_levels
  
  if (nrow(dat) == 0) {
    p <- ggplot() + theme_void() + ggtitle(title_lab)
    ggsave(file.path(OUT_DIR, pdf_name), p, width = width, height = height)
    ggsave(file.path(OUT_DIR, png_name), p, width = width, height = height, dpi = 600)
    return(invisible(NULL))
  }
  
  r_max <- max(dat$r, na.rm = TRUE)
  r_max <- max(r_max, MIN_RADIUS * 1.6)
  
  circle_df <- make_circle_data(sink_levels, source_levels, r_max, ring_n = RING_N)
  cross_df  <- make_cross_data(sink_levels, source_levels, r_max)
  
  label_df <- dat %>%
    distinct(SinkGroup, SourceGroup) %>%
    mutate(
      lab_top    = "0.00/1.00",
      lab_bottom = "0.50",
      lab_left   = "0.75",
      lab_right  = "0.25"
    )
  
  p <- ggplot() +
    ggforce::geom_circle(
      data = circle_df,
      aes(x0 = x0, y0 = y0, r = r),
      color = "#D0D0D0",
      linewidth = 0.55,
      fill = NA
    ) +
    geom_segment(
      data = cross_df$h,
      aes(x = x, xend = xend, y = y, yend = yend),
      color = "#D0D0D0",
      linewidth = 0.55
    ) +
    geom_segment(
      data = cross_df$v,
      aes(x = x, xend = xend, y = y, yend = yend),
      color = "#D0D0D0",
      linewidth = 0.55
    ) +
    geom_scatterpie(
      data = dat,
      aes(x = x, y = y, r = r),
      cols = taxa_cols,
      color = NA
    ) +
    facet_grid(
      SinkGroup ~ SourceGroup,
      switch = "both",
      drop = FALSE
    ) +
    coord_fixed(
      xlim = c(-r_max * 1.30, r_max * 1.30),
      ylim = c(-r_max * 1.30, r_max * 1.30),
      clip = "off"
    ) +
    scale_fill_manual(values = taxa_palette, breaks = taxa_cols, drop = FALSE) +
    geom_text(
      data = label_df,
      aes(x = 0, y = r_max * TOP_LABEL_MULT, label = lab_top),
      size = 3.3,
      fontface = "plain"
    ) +
    geom_text(
      data = label_df,
      aes(x = 0, y = -r_max * BOTTOM_LABEL_MULT, label = lab_bottom),
      size = 3.1,
      fontface = "plain"
    ) +
    geom_text(
      data = label_df,
      aes(x = -r_max * LEFT_LABEL_MULT, y = 0, label = lab_left),
      size = 3.1,
      fontface = "plain"
    ) +
    geom_text(
      data = label_df,
      aes(x = r_max * RIGHT_LABEL_MULT, y = 0, label = lab_right),
      size = 3.1,
      fontface = "plain"
    ) +
    labs(
      title = title_lab,
      x = "Abundance",
      y = NULL,
      fill = "Taxa"
    ) +
    theme_bw(base_size = BASE_SIZE) +
    theme(
      panel.background = element_rect(fill = "#F7F7F7", color = NA),
      plot.background  = element_rect(fill = "white", color = NA),
      
      panel.grid = element_blank(),
      axis.text = element_blank(),
      axis.ticks = element_blank(),
      axis.title.y = element_blank(),
      axis.title.x = element_text(face = "bold", size = 12, margin = margin(t = 12)),
      axis.line = element_blank(),
      
      strip.placement = "outside",
      strip.background = element_rect(fill = "#D9D9D9", color = "#B5B5B5", linewidth = 0.9),
      strip.text.x = element_text(face = "bold", size = 10, margin = margin(4, 2, 4, 2)),
      strip.text.y.left = element_text(face = "bold", size = 10, angle = 270, margin = margin(2, 4, 2, 4)),
      
      panel.border = element_rect(fill = NA, color = "#B5B5B5", linewidth = 0.9),
      
      plot.title = element_text(face = "bold", size = 28, hjust = 0, margin = margin(b = 10)),
      
      legend.position = "right",
      legend.title = element_text(face = "bold", size = 12),
      legend.text = element_text(size = 9, face = "italic"),
      legend.key.height = unit(0.42, "cm"),
      legend.key.width  = unit(0.42, "cm"),
      
      panel.spacing.x = unit(0.16, "lines"),
      panel.spacing.y = unit(0.16, "lines"),
      
      plot.margin = margin(12, 22, 14, 14)
    ) +
    guides(fill = guide_legend(ncol = 1, byrow = TRUE))
  
  if (USE_CAIRO_PDF) {
    ggsave(file.path(OUT_DIR, pdf_name), p, width = width, height = height, device = cairo_pdf)
  } else {
    ggsave(file.path(OUT_DIR, pdf_name), p, width = width, height = height)
  }
  ggsave(file.path(OUT_DIR, png_name), p, width = width, height = height, dpi = 700)
  
  invisible(p)
}

# =========================================================
# prepare
# =========================================================
dA_with  <- prep_panel(df, farm_sinks,      farm_sources,      keep_unknown = TRUE)
dB_with  <- prep_panel(df, slaughter_sinks, slaughter_sources, keep_unknown = TRUE)
dC_with  <- prep_panel(df, market_sinks,    market_sources,    keep_unknown = TRUE)

dA_known <- prep_panel(df, farm_sinks,      farm_sources,      keep_unknown = FALSE)
dB_known <- prep_panel(df, slaughter_sinks, slaughter_sources, keep_unknown = FALSE)
dC_known <- prep_panel(df, market_sinks,    market_sources,    keep_unknown = FALSE)

# =========================================================
# save
# =========================================================
plot_one_panel(
  dA_with, "A",
  "Fig3_A_with_unknown_scatterpie_v3_aggressive.pdf",
  "Fig3_A_with_unknown_scatterpie_v3_aggressive.png",
  width = 13.2, height = 5.6
)

plot_one_panel(
  dB_with, "B",
  "Fig3_B_with_unknown_scatterpie_v3_aggressive.pdf",
  "Fig3_B_with_unknown_scatterpie_v3_aggressive.png",
  width = 11.8, height = 4.9
)

plot_one_panel(
  dC_with, "C",
  "Fig3_C_with_unknown_scatterpie_v3_aggressive.pdf",
  "Fig3_C_with_unknown_scatterpie_v3_aggressive.png",
  width = 9.3, height = 4.0
)

plot_one_panel(
  dA_known, "A",
  "Fig3_A_known_only_scatterpie_v3_aggressive.pdf",
  "Fig3_A_known_only_scatterpie_v3_aggressive.png",
  width = 12.4, height = 5.6
)

plot_one_panel(
  dB_known, "B",
  "Fig3_B_known_only_scatterpie_v3_aggressive.pdf",
  "Fig3_B_known_only_scatterpie_v3_aggressive.png",
  width = 10.8, height = 4.9
)

plot_one_panel(
  dC_known, "C",
  "Fig3_C_known_only_scatterpie_v3_aggressive.pdf",
  "Fig3_C_known_only_scatterpie_v3_aggressive.png",
  width = 8.6, height = 4.0
)

cat("Saved optimized aggressive scatterpie-style panels into folder:\n", OUT_DIR, "\n")