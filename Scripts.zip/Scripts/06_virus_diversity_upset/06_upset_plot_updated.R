# ============================================================
# 09_upset_plot_updated_v3_CFSM_order.R
# Purpose:
#   1) Build presence/absence matrix of vOTUs and MAGs across groups
#   2) UpSet-style intersection bar plot (ggupset)
#   3) Pie chart: how many features are shared by k groups (k=1..N)
#   4) Boxplot: summed relative abundance (%) of features shared by ALL groups
#
# Inputs (default):
#   - Group.xlsx           : columns ID, Group
#   - virus_95_75_10.tsv   : first column Contig, remaining columns = samples (TPM/abundance)
#   - mags_95_75_10.tsv    : first column MAG, remaining columns = samples (TPM/abundance)
#
# Outputs:
#   - results_upset/Fig_vOTUs_UpSet.pdf / Fig_vOTUs_SharedK_Pie.pdf / Fig_vOTUs_SharedAll_Box.pdf
#   - results_upset/Fig_MAGs_UpSet.pdf  / Fig_MAGs_SharedK_Pie.pdf  / Fig_MAGs_SharedAll_Box.pdf
#   - results_upset/shared_vOTUs_all_groups.tsv
#   - results_upset/shared_MAGs_all_groups.tsv
#   - results_upset/intersection_counts_vOTUs.tsv
#   - results_upset/intersection_counts_MAGs.tsv
#
# Run:
# Rscript 09_upset_plot_updated_v3_CFSM_order.R
# Rscript 09_upset_plot_updated_v3_CFSM_order.R Group.xlsx virus_95_75_10.tsv mags_95_75_10.tsv
# ============================================================

suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(tibble)
  library(readxl)
  library(stringr)
  library(RColorBrewer)
  library(ggthemes)
  library(ggupset)
  library(patchwork)
})

# ---------------------------
# 0) Inputs (support CLI args)
# ---------------------------
group_file <- "Group.xlsx"
virus_file <- "virus_95_75_10.tsv"
mags_file  <- "mags_95_75_10.tsv"

args <- commandArgs(trailingOnly = TRUE)
if (length(args) >= 1) group_file <- args[1]
if (length(args) >= 2) virus_file <- args[2]
if (length(args) >= 3) mags_file  <- args[3]

stopifnot(file.exists(group_file))
stopifnot(file.exists(virus_file))
stopifnot(file.exists(mags_file))

outdir <- "results_upset"
dir.create(outdir, showWarnings = FALSE, recursive = TRUE)

# ---------------------------
# 1) Read group table
# ---------------------------
group <- read_excel(group_file) %>% as.data.frame()

if (!all(c("ID", "Group") %in% colnames(group))) {
  stop("Group.xlsx 必须包含两列：ID 和 Group（大小写一致）")
}

group <- group %>%
  transmute(samples = as.character(ID),
            group   = as.character(Group))

# ---------------------------
# 1.1) Group order: C -> F -> S -> M
#      keep original within-stage order from Group.xlsx
# ---------------------------
order_groups_cfms <- function(groups) {
  g <- unique(as.character(groups))
  stage <- stringr::str_extract(g, "^[A-Za-z]")
  stage_rank <- dplyr::case_when(
    stage == "C" ~ 1L,
    stage == "F" ~ 2L,
    stage == "S" ~ 3L,
    stage == "M" ~ 4L,
    TRUE         ~ 99L
  )
  original_rank <- seq_along(g)
  g[order(stage_rank, original_rank)]
}

group_levels <- order_groups_cfms(group$group)
group$group  <- factor(group$group, levels = group_levels)
n_groups <- length(group_levels)

message("Groups (N=", n_groups, "): ", paste(group_levels, collapse = ", "))

# ---------------------------
# 2) Helpers
# ---------------------------
read_feature_table <- function(file, id_candidates = c("Contig", "MAG")) {
  df <- read.delim(file, sep = "\t", header = TRUE, check.names = FALSE)
  id_col <- NULL
  for (cand in id_candidates) {
    if (cand %in% colnames(df)) { id_col <- cand; break }
  }
  if (is.null(id_col)) {
    id_col <- colnames(df)[1]
  }
  feature_id <- as.character(df[[id_col]])
  df <- df[, setdiff(colnames(df), id_col), drop = FALSE]
  
  df[] <- lapply(df, function(x) as.numeric(as.character(x)))
  df[is.na(df)] <- 0
  
  rownames(df) <- feature_id
  return(df)
}

calc_relative_abundance <- function(mat) {
  cs <- colSums(mat, na.rm = TRUE)
  cs[cs == 0] <- 1
  sweep(mat, 2, cs, "/") * 100
}

presence_matrix_by_group <- function(mat, group_df, group_levels) {
  present <- sapply(group_levels, function(g) {
    sam <- group_df$samples[group_df$group == g]
    sam <- intersect(sam, colnames(mat))
    if (length(sam) == 0) {
      rep(0L, nrow(mat))
    } else {
      as.integer(rowSums(mat[, sam, drop = FALSE] > 0, na.rm = TRUE) > 0)
    }
  })
  present <- as.data.frame(present, check.names = FALSE)
  rownames(present) <- rownames(mat)
  present
}

build_upset_df <- function(pres_df, group_levels) {
  long <- pres_df %>%
    rownames_to_column("Feature") %>%
    pivot_longer(cols = -Feature, names_to = "Group", values_to = "presence") %>%
    filter(presence == 1)
  
  upset <- long %>%
    group_by(Feature) %>%
    summarise(
      GroupList = list(unique(Group)[order(match(unique(Group), group_levels))]),
      .groups = "drop"
    ) %>%
    mutate(
      GroupKey = vapply(GroupList, function(x) paste(x, collapse = "&"), character(1)),
      num_groups = lengths(GroupList)
    )
  
  counts <- upset %>%
    count(GroupKey, num_groups, name = "n_features") %>%
    arrange(desc(n_features))
  
  upset2 <- upset %>%
    left_join(counts, by = c("GroupKey", "num_groups")) %>%
    mutate(
      highlight = ifelse(num_groups == length(group_levels), "all_groups", "normal")
    )
  
  list(upset = upset2, counts = counts)
}

# ---------------------------
# Plot sizing helpers (auto)
# ---------------------------
auto_base_size <- function(n_groups) {
  if (n_groups <= 9) return(11)
  if (n_groups <= 14) return(10)
  return(9)
}
base_size_auto <- auto_base_size(n_groups)

calc_dims_upset <- function(n_groups, n_intersections) {
  width  <- max(11, min(24, 8 + 0.18 * n_intersections))
  height <- max(7,  min(16, 5.5 + 0.28 * n_groups))
  list(width = width, height = height)
}

calc_dims_box <- function(n_groups) {
  width  <- max(8, min(18, 3 + 0.85 * n_groups))
  height <- 6
  list(width = width, height = height)
}

calc_dims_pie <- function() {
  list(width = 7, height = 5)
}

plot_upset_main <- function(upset_df, group_levels, y_max = NULL, n_intersections = 50, base_size = 11) {
  if (is.null(y_max)) {
    y_max <- max(upset_df$n_features, na.rm = TRUE)
    y_max <- ceiling(y_max * 1.15)
  }
  
  label_size <- ifelse(n_intersections >= 50, 2.2, ifelse(n_intersections >= 35, 2.6, 3.0))
  
  ggplot(upset_df, aes(x = GroupList)) +
    geom_bar(aes(fill = highlight)) +
    geom_text(stat = "count", aes(label = after_stat(count)),
              vjust = -0.35, size = label_size) +
    scale_x_upset(
      sets = group_levels,
      n_intersections = n_intersections,
      reverse = FALSE,
      order_by = "freq"
    ) +
    scale_y_continuous(limits = c(0, y_max), expand = c(0, 0)) +
    scale_fill_manual(values = c("all_groups" = "#e66d50", "normal" = "#0074b3")) +
    labs(y = "Intersection size", x = NULL) +
    theme_test(base_size = base_size) +
    theme(
      panel.grid = element_blank(),
      panel.border = element_rect(color = "black", fill = NA),
      axis.title = element_blank(),
      axis.title.y = element_text(colour = "black", size = base_size + 1, margin = margin(r = 5), face = "bold"),
      axis.text = element_text(color = "black"),
      axis.ticks.x = element_blank(),
      legend.position = "none",
      plot.margin = unit(c(0.35, 0.35, 0.35, 0.35), "cm")
    )
}

plot_pie_by_num_groups <- function(upset_df, n_groups, base_size = 10) {
  tmp <- upset_df %>%
    distinct(Feature, num_groups) %>%
    count(num_groups, name = "count") %>%
    arrange(num_groups) %>%
    mutate(
      percentage = count / sum(count),
      label = paste0(count, "\n", sprintf("%.1f%%", percentage * 100))
    )
  
  ggplot(tmp, aes(x = 2, y = count, fill = as.numeric(num_groups))) +
    geom_bar(stat = "identity", width = 1, color = "white") +
    coord_polar(theta = "y") +
    xlim(0.5, 2.5) +
    theme_void(base_size = base_size) +
    geom_text(aes(label = label),
              position = position_stack(vjust = 0.5),
              size = 3.6, color = "black", fontface = "bold") +
    scale_fill_gradientn(
      colors = colorRampPalette(c("#deebf7", "#3182bd", "#08519c"))(n_groups),
      name = "Number of groups"
    ) +
    theme(
      legend.position = "right",
      legend.title = element_text(size = base_size, face = "bold"),
      legend.text = element_text(size = base_size - 1)
    )
}

plot_shared_box <- function(shared_features, rel_mat, group_df, group_levels,
                            y_limits = NULL, ylab = "", base_size = 11, x_angle = 45) {
  sam_all <- intersect(group_df$samples, colnames(rel_mat))
  rel_mat <- rel_mat[, sam_all, drop = FALSE]
  
  if (length(shared_features) == 0) {
    return(
      ggplot() +
        annotate("text", x = 0, y = 0, label = "No features shared by ALL groups", size = 5) +
        theme_void(base_size = base_size)
    )
  }
  
  shared_mat <- rel_mat[shared_features, , drop = FALSE]
  sum_per_sample <- colSums(shared_mat, na.rm = TRUE)
  
  df <- data.frame(
    samples = names(sum_per_sample),
    sum_abundance = as.numeric(sum_per_sample),
    stringsAsFactors = FALSE
  ) %>%
    left_join(group_df, by = "samples") %>%
    mutate(group = factor(as.character(group), levels = group_levels))
  
  p <- ggplot(df, aes(x = group, y = sum_abundance, fill = group)) +
    geom_boxplot(outlier.shape = NA) +
    geom_jitter(shape = 1, width = 0.2, size = 1.7, color = "black") +
    scale_fill_manual(values = colorRampPalette(brewer.pal(12, "Paired"))(length(group_levels))) +
    theme_test(base_size = base_size) +
    theme(
      axis.title = element_blank(),
      axis.title.y = element_text(colour = "black", size = base_size + 1, margin = margin(r = 5), face = "bold"),
      axis.text.y = element_text(color = "black"),
      axis.text.x = element_text(color = "black", angle = x_angle, hjust = 1, vjust = 1),
      axis.ticks.x = element_blank(),
      legend.position = "none",
      plot.margin = unit(c(0.35, 0.35, 0.35, 0.35), "cm")
    ) +
    labs(y = ylab)
  
  if (!is.null(y_limits) && length(y_limits) == 2) {
    p <- p + scale_y_continuous(limits = y_limits)
  }
  
  p
}

make_composite <- function(main_upset, pie_plot, box_plot) {
  main_upset +
    inset_element(box_plot, left = 0.62, bottom = 0.35, right = 0.98, top = 0.92) +
    inset_element(pie_plot, left = 0.34, bottom = 0.35, right = 0.60, top = 0.92)
}

# ---------------------------
# 3) vOTUs: presence + upset
# ---------------------------
votu_mat_all <- read_feature_table(virus_file, id_candidates = c("Contig", "vOTU", "Virus", "ID"))
keep_samples <- intersect(group$samples, colnames(votu_mat_all))
if (length(keep_samples) == 0) {
  stop("virus_95_75_10.tsv 中找不到任何 Group.xlsx 的样本列名，请检查是否命名一致。")
}
votu_mat <- votu_mat_all[, keep_samples, drop = FALSE]
votu_rel <- calc_relative_abundance(votu_mat)

votu_pres <- presence_matrix_by_group(votu_mat, group, group_levels)
votu_upset_obj <- build_upset_df(votu_pres, group_levels)
votu_upset_df <- votu_upset_obj$upset
votu_counts   <- votu_upset_obj$counts

votu_main <- plot_upset_main(votu_upset_df, group_levels, n_intersections = 50, base_size = base_size_auto)
votu_pie  <- plot_pie_by_num_groups(votu_upset_df, n_groups, base_size = base_size_auto)

shared_votu <- votu_upset_df %>%
  filter(highlight == "all_groups") %>%
  pull(Feature) %>%
  unique()

votu_box <- plot_shared_box(
  shared_features = shared_votu,
  rel_mat = votu_rel,
  group_df = group,
  group_levels = group_levels,
  y_limits = NULL,
  ylab = "Relative abundance (%) of vOTUs shared by ALL groups",
  base_size = base_size_auto,
  x_angle = 45
)

write.table(data.frame(Contig = shared_votu), file = file.path(outdir, "shared_vOTUs_all_groups.tsv"),
            sep = "\t", row.names = FALSE, quote = FALSE)
write.table(votu_counts, file = file.path(outdir, "intersection_counts_vOTUs.tsv"),
            sep = "\t", row.names = FALSE, quote = FALSE)

message("vOTUs shared by ALL groups: ", length(shared_votu))

# ---------------------------
# 4) MAGs: presence + upset
# ---------------------------
mags_mat_all <- read_feature_table(mags_file, id_candidates = c("MAG", "Bin", "ID"))
keep_samples_m <- intersect(group$samples, colnames(mags_mat_all))
if (length(keep_samples_m) == 0) {
  stop("mags_95_75_10.tsv 中找不到任何 Group.xlsx 的样本列名，请检查是否命名一致。")
}
mags_mat <- mags_mat_all[, keep_samples_m, drop = FALSE]
mags_rel <- calc_relative_abundance(mags_mat)

mags_pres <- presence_matrix_by_group(mags_mat, group, group_levels)
mags_upset_obj <- build_upset_df(mags_pres, group_levels)
mags_upset_df <- mags_upset_obj$upset
mags_counts   <- mags_upset_obj$counts

mags_main <- plot_upset_main(mags_upset_df, group_levels, y_max = NULL, n_intersections = 50, base_size = base_size_auto)
mags_pie  <- plot_pie_by_num_groups(mags_upset_df, n_groups, base_size = base_size_auto)

shared_mags <- mags_upset_df %>%
  filter(highlight == "all_groups") %>%
  pull(Feature) %>%
  unique()

mags_box <- plot_shared_box(
  shared_features = shared_mags,
  rel_mat = mags_rel,
  group_df = group,
  group_levels = group_levels,
  y_limits = NULL,
  ylab = "Relative abundance (%) of MAGs shared by ALL groups",
  base_size = base_size_auto,
  x_angle = 45
)

write.table(data.frame(MAG = shared_mags), file = file.path(outdir, "shared_MAGs_all_groups.tsv"),
            sep = "\t", row.names = FALSE, quote = FALSE)
write.table(mags_counts, file = file.path(outdir, "intersection_counts_MAGs.tsv"),
            sep = "\t", row.names = FALSE, quote = FALSE)

message("MAGs shared by ALL groups: ", length(shared_mags))

# ---------------------------
# 5) Export PDFs (each plot separately; auto sizing)
# ---------------------------
dims_upset <- calc_dims_upset(n_groups, n_intersections = 50)
dims_box   <- calc_dims_box(n_groups)
dims_pie   <- calc_dims_pie()

ggsave(file.path(outdir, "Fig_vOTUs_UpSet.pdf"), votu_main,
       width = dims_upset$width, height = dims_upset$height, useDingbats = FALSE)
ggsave(file.path(outdir, "Fig_vOTUs_SharedK_Pie.pdf"), votu_pie,
       width = dims_pie$width, height = dims_pie$height, useDingbats = FALSE)
ggsave(file.path(outdir, "Fig_vOTUs_SharedAll_Box.pdf"), votu_box,
       width = dims_box$width, height = dims_box$height, useDingbats = FALSE)

ggsave(file.path(outdir, "Fig_MAGs_UpSet.pdf"), mags_main,
       width = dims_upset$width, height = dims_upset$height, useDingbats = FALSE)
ggsave(file.path(outdir, "Fig_MAGs_SharedK_Pie.pdf"), mags_pie,
       width = dims_pie$width, height = dims_pie$height, useDingbats = FALSE)
ggsave(file.path(outdir, "Fig_MAGs_SharedAll_Box.pdf"), mags_box,
       width = dims_box$width, height = dims_box$height, useDingbats = FALSE)

message("Saved PDFs to: ", normalizePath(outdir))